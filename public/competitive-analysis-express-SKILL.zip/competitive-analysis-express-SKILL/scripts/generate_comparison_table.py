#!/usr/bin/env python3
"""
Generate comparison tables for competitive analysis.

This script creates multi-format comparison tables:
- Markdown formatted table
- CSV export for data analysis
- Excel file with multiple sheets and charts

Usage:
    python generate_comparison_table.py --output analysis_output --format markdown,csv,excel
"""

import argparse
import json
import csv
from pathlib import Path
from typing import List, Dict, Any
import pandas as pd


def create_markdown_table(
    competitors: List[Dict[str, Any]],
    criteria: List[str],
    output_path: Path
) -> None:
    """
    Create a markdown formatted comparison table.

    Args:
        competitors: List of competitor data
        criteria: List of criteria to compare
        output_path: Directory to save the output file
    """
    output_file = output_path / 'comparison_table.md'

    with open(output_file, 'w', encoding='utf-8') as f:
        # Write title
        f.write("# TABLEAU COMPARATIF CONCURRENTIEL\n\n")
        f.write(f"*Généré automatiquement - {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}*\n\n")

        # Create header
        headers = ['Critère'] + [comp.get('name', 'N/A') for comp in competitors]
        separator = ['---'] * len(headers)

        # Write header
        f.write('| ' + ' | '.join(headers) + ' |\n')
        f.write('| ' + ' | '.join(separator) + ' |\n')

        # Group criteria by category
        categories = {
            'PRICING & BUSINESS MODEL': ['Prix', 'Modèle économique', 'Prix moyen panier'],
            'POSITIONNEMENT': ['Cible principale', 'Message clé', 'Positionnement'],
            'PRODUIT/SERVICE': ['Fonctionnalités', 'Qualité', 'Innovation'],
            'EXPÉRIENCE CLIENT': ['Support client', 'Facilité d\'utilisation', 'Onboarding'],
            'PERFORMANCE': ['Fiabilité', 'Performance', 'Sécurité']
        }

        # Write each category
        for category, cat_criteria in categories.items():
            # Category header
            f.write(f'| **{category}** |' + ' |' * len(competitors) + '\n')

            # Criteria in category
            for criterion in cat_criteria:
                if criterion in criteria:
                    row = [f'**{criterion}**']
                    for comp in competitors:
                        value = comp.get('criteria', {}).get(criterion, 'N/A')
                        # Add emoji for "VOUS"
                        if comp.get('is_you', False):
                            row.append(f'⭐ {value}')
                        else:
                            row.append(str(value))
                    f.write('| ' + ' | '.join(row) + ' |\n')

        # Write strengths and weaknesses
        f.write('| **PERCEPTION** |' + ' |' * len(competitors) + '\n')

        # Strengths
        strengths_row = ['**Forces**']
        for comp in competitors:
            strengths = comp.get('strengths', [])
            if strengths:
                strengths_str = '<br>'.join([f'✅ {s}' for s in strengths[:3]])
                strengths_row.append(strengths_str)
            else:
                strengths_row.append('N/A')
        f.write('| ' + ' | '.join(strengths_row) + ' |\n')

        # Weaknesses
        weaknesses_row = ['**Faiblesses**']
        for comp in competitors:
            weaknesses = comp.get('weaknesses', [])
            if weaknesses:
                weaknesses_str = '<br>'.join([f'❌ {w}' for w in weaknesses[:3]])
                weaknesses_row.append(weaknesses_str)
            else:
                weaknesses_row.append('N/A')
        f.write('| ' + ' | '.join(weaknesses_row) + ' |\n')

        # Add legend
        f.write("\n\n## Légende\n\n")
        f.write("- ⭐ : Votre entreprise\n")
        f.write("- ✅ : Forces identifiées\n")
        f.write("- ❌ : Faiblesses identifiées\n")

    print(f"✅ Tableau Markdown généré : {output_file}")


def create_csv_export(
    competitors: List[Dict[str, Any]],
    criteria: List[str],
    output_path: Path
) -> None:
    """
    Create a CSV export of comparison data.

    Args:
        competitors: List of competitor data
        criteria: List of criteria to compare
        output_path: Directory to save the output file
    """
    output_file = output_path / 'comparison_data.csv'

    with open(output_file, 'w', encoding='utf-8', newline='') as f:
        # Create header
        headers = ['Critère'] + [comp.get('name', 'N/A') for comp in competitors]
        writer = csv.writer(f)
        writer.writerow(headers)

        # Write criteria rows
        for criterion in criteria:
            row = [criterion]
            for comp in competitors:
                value = comp.get('criteria', {}).get(criterion, '')
                row.append(value)
            writer.writerow(row)

        # Write strengths
        writer.writerow([])
        strengths_row = ['Forces']
        for comp in competitors:
            strengths = comp.get('strengths', [])
            strengths_str = '; '.join(strengths) if strengths else ''
            strengths_row.append(strengths_str)
        writer.writerow(strengths_row)

        # Write weaknesses
        weaknesses_row = ['Faiblesses']
        for comp in competitors:
            weaknesses = comp.get('weaknesses', [])
            weaknesses_str = '; '.join(weaknesses) if weaknesses else ''
            weaknesses_row.append(weaknesses_str)
        writer.writerow(weaknesses_row)

    print(f"✅ Export CSV généré : {output_file}")


def create_excel_export(
    competitors: List[Dict[str, Any]],
    criteria: List[str],
    output_path: Path
) -> None:
    """
    Create an Excel export with multiple sheets and charts.

    Args:
        competitors: List of competitor data
        criteria: List of criteria to compare
        output_path: Directory to save the output file
    """
    output_file = output_path / 'comparison_analysis.xlsx'

    # Create Excel writer
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Sheet 1: Comparison table
        comp_names = [comp.get('name', 'N/A') for comp in competitors]
        data = {}
        data['Critère'] = criteria

        for comp in competitors:
            name = comp.get('name', 'N/A')
            data[name] = [comp.get('criteria', {}).get(crit, '') for crit in criteria]

        df_comparison = pd.DataFrame(data)
        df_comparison.to_excel(writer, sheet_name='Comparaison', index=False)

        # Sheet 2: Scoring (if scores exist)
        score_criteria = ['Prix', 'Fonctionnalités', 'Support', 'Facilité', 'Innovation', 'Fiabilité']
        score_data = {}
        score_data['Critère'] = score_criteria

        for comp in competitors:
            name = comp.get('name', 'N/A')
            scores = comp.get('scores', {})
            score_data[name] = [scores.get(crit, 5) for crit in score_criteria]

        df_scores = pd.DataFrame(score_data)
        df_scores.to_excel(writer, sheet_name='Scoring', index=False)

        # Sheet 3: Strengths & Weaknesses
        sw_data = {
            'Concurrent': [],
            'Type': [],
            'Description': []
        }

        for comp in competitors:
            name = comp.get('name', 'N/A')
            # Strengths
            for strength in comp.get('strengths', []):
                sw_data['Concurrent'].append(name)
                sw_data['Type'].append('Force')
                sw_data['Description'].append(strength)
            # Weaknesses
            for weakness in comp.get('weaknesses', []):
                sw_data['Concurrent'].append(name)
                sw_data['Type'].append('Faiblesse')
                sw_data['Description'].append(weakness)

        df_sw = pd.DataFrame(sw_data)
        df_sw.to_excel(writer, sheet_name='Forces-Faiblesses', index=False)

        # Sheet 4: Summary statistics
        summary_data = {
            'Concurrent': comp_names,
            'Score Moyen': [
                sum(comp.get('scores', {}).values()) / len(comp.get('scores', {})) if comp.get('scores') else 0
                for comp in competitors
            ],
            'Prix Score': [comp.get('price_score', 5) for comp in competitors],
            'Valeur Score': [comp.get('value_score', 5) for comp in competitors],
            'Nombre de Forces': [len(comp.get('strengths', [])) for comp in competitors],
            'Nombre de Faiblesses': [len(comp.get('weaknesses', [])) for comp in competitors]
        }

        df_summary = pd.DataFrame(summary_data)
        df_summary.to_excel(writer, sheet_name='Synthèse', index=False)

    print(f"✅ Export Excel généré : {output_file}")
    print(f"   → 4 onglets : Comparaison, Scoring, Forces-Faiblesses, Synthèse")


def main():
    """Main function to generate comparison tables."""
    parser = argparse.ArgumentParser(
        description='Generate comparison tables for competitive analysis'
    )
    parser.add_argument('--input', type=str, default='competitors_data.json',
                       help='Input JSON file with competitor data')
    parser.add_argument('--output', type=str, default='output',
                       help='Output directory for generated files')
    parser.add_argument('--format', type=str, default='markdown,csv,excel',
                       help='Output formats (markdown, csv, excel), comma-separated')

    args = parser.parse_args()

    # Create output directory
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Load competitor data
    input_file = Path(args.input)
    if input_file.exists():
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            competitors = data.get('competitors', [])
            criteria = data.get('criteria', [])
    else:
        # Example data if no input file
        print("⚠️  Fichier d'entrée non trouvé. Utilisation de données d'exemple.")
        competitors = [
            {
                'name': 'VOUS',
                'is_you': True,
                'price_score': 6,
                'value_score': 8,
                'criteria': {
                    'Prix': '12€/user',
                    'Modèle économique': 'SaaS mensuel',
                    'Cible principale': 'PME 5-50 employés',
                    'Message clé': 'Simplicité et support FR',
                    'Fonctionnalités': 'Core essentielles',
                    'Support client': '⭐⭐⭐⭐⭐ FR',
                    'Facilité d\'utilisation': '⭐⭐⭐⭐⭐',
                    'Fiabilité': '⭐⭐⭐⭐'
                },
                'scores': {
                    'Prix': 6,
                    'Fonctionnalités': 8,
                    'Support': 9,
                    'Facilité': 8,
                    'Innovation': 7,
                    'Fiabilité': 8
                },
                'strengths': [
                    'Support client français réactif',
                    'Interface intuitive',
                    'Prix compétitif'
                ],
                'weaknesses': [
                    'Moins de features que les leaders',
                    'Marque moins connue'
                ]
            },
            {
                'name': 'Concurrent A',
                'price_score': 8,
                'value_score': 7,
                'criteria': {
                    'Prix': '24€/user',
                    'Modèle économique': 'SaaS annuel',
                    'Cible principale': 'Grandes entreprises',
                    'Message clé': 'Leader du marché',
                    'Fonctionnalités': 'Très complètes',
                    'Support client': '⭐⭐ EN uniquement',
                    'Facilité d\'utilisation': '⭐⭐',
                    'Fiabilité': '⭐⭐⭐⭐⭐'
                },
                'scores': {
                    'Prix': 3,
                    'Fonctionnalités': 9,
                    'Support': 6,
                    'Facilité': 5,
                    'Innovation': 8,
                    'Fiabilité': 9
                },
                'strengths': [
                    'Fonctionnalités très complètes',
                    'Fiabilité éprouvée',
                    'Grande notoriété'
                ],
                'weaknesses': [
                    'Prix élevé',
                    'Complexité',
                    'Support limité en français'
                ]
            },
            {
                'name': 'Concurrent B',
                'price_score': 4,
                'value_score': 5,
                'criteria': {
                    'Prix': '10€/user',
                    'Modèle économique': 'Freemium',
                    'Cible principale': 'Startups',
                    'Message clé': 'Simple et gratuit',
                    'Fonctionnalités': 'Basiques',
                    'Support client': '⭐⭐ Self-service',
                    'Facilité d\'utilisation': '⭐⭐⭐⭐',
                    'Fiabilité': '⭐⭐⭐'
                },
                'scores': {
                    'Prix': 8,
                    'Fonctionnalités': 6,
                    'Support': 5,
                    'Facilité': 8,
                    'Innovation': 5,
                    'Fiabilité': 7
                },
                'strengths': [
                    'Prix très compétitif',
                    'Interface simple',
                    'Freemium attractif'
                ],
                'weaknesses': [
                    'Fonctionnalités limitées',
                    'Support minimal',
                    'Fiabilité perfectible'
                ]
            }
        ]
        criteria = [
            'Prix', 'Modèle économique', 'Cible principale', 'Message clé',
            'Fonctionnalités', 'Support client', 'Facilité d\'utilisation', 'Fiabilité'
        ]

    # Generate tables for each format
    formats = [f.strip() for f in args.format.split(',')]

    print(f"\n📊 Génération des tableaux comparatifs...\n")

    for fmt in formats:
        if fmt == 'markdown':
            create_markdown_table(competitors, criteria, output_path)
        elif fmt == 'csv':
            create_csv_export(competitors, criteria, output_path)
        elif fmt == 'excel':
            create_excel_export(competitors, criteria, output_path)
        else:
            print(f"⚠️  Format non reconnu : {fmt}")

    print(f"\n✅ Tous les tableaux ont été générés dans : {output_path}")
    print(f"\n💡 Pour personnaliser, créez un fichier '{args.input}' avec vos données.")


if __name__ == '__main__':
    main()

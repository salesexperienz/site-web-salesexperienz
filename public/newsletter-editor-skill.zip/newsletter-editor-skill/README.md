# Newsletter Editor Skill

Skill Claude qui formate le contenu d'une newsletter rédigée en JSON prêt à importer dans l'éditeur de newsletter Sales Expérienz.

## Ce que fait ce skill

1. Prend le texte d'une newsletter rédigée (format libre)
2. Identifie et mappe chaque section vers le bon champ de l'éditeur
3. Génère un JSON propre, immédiatement importable

## Installation

### Claude Code (Claude CLI)

1. Copie le fichier `SKILL.md` dans :
   ```
   ~/.claude/commands/newsletter.md
   ```
2. Utilise-le avec `/newsletter [ton texte]`

### Claude.ai (interface web)

1. Télécharge `newsletter-editor-skill.zip`
2. Va dans Claude.ai → Paramètres → Skills
3. Clique "Importer un skill"
4. Upload le fichier ZIP

## Utilisation

### Dans Claude Code

```
/newsletter [colle ici le texte de ta newsletter]
```

### Dans Claude.ai

```
Utilise le skill newsletter avec ce texte :
[colle ici le texte de ta newsletter]
```

## Workflow complet

```
Rédiger dans Claude Project
        ↓
/newsletter [texte validé]
        ↓
Claude génère le JSON
        ↓
Coller dans l'éditeur → "Importer depuis Claude"
        ↓
Peaufiner dans l'éditeur
        ↓
Télécharger le ZIP final
```

## Compatibilité

Conçu pour l'éditeur de newsletter Sales Expérienz.
Champs supportés : `edition`, `categorie`, `titre`, `soustitre`, `intro`, `sommaire`, `s1titre`, `s1corps`, `s1resume`, `s2titre`, `s2item1/2/3`, `s3titre`, `s3items`, `s4titre`, `s4corps`, `chiffre`, `chiffreTexte`, `actionsH`, `action1/2/3`, `ctotire`, `conclu`, `ps`

## Structure des fichiers

```
newsletter-editor-skill/
├── SKILL.md          — Instructions principales du skill
├── README.md         — Documentation
├── QUICK_START.md    — Démarrage rapide
└── EXAMPLE_USAGE.md  — Exemples d'utilisation
```

## Version

**v1.0.0** — Version initiale

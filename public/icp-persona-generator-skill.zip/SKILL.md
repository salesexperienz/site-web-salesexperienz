---
name: icp-persona-generator
description: Génère des profils clients idéaux (ICP/Persona) détaillés avec pain points, motivations, objections et stratégies d'approche pour optimiser la prospection commerciale.
---

# SKILL: ICP & PERSONA GENERATOR

## Vue d'ensemble
Ce skill permet de créer des profils clients idéaux (Ideal Customer Profile - ICP) et des personas détaillés pour cibler efficacement vos actions commerciales et marketing. Un bon persona transforme vos efforts de prospection en éliminant les approximations.

## Quand utiliser ce skill
- Définir sa cible commerciale avant de lancer une campagne
- Affiner son positionnement et son discours de vente
- Préparer une stratégie de prospection ciblée
- Comprendre les motivations d'achat de ses clients
- Former son équipe commerciale sur les profils clients
- Créer du contenu marketing adapté à ses cibles

## PARTIE 1 : ICP (IDEAL CUSTOMER PROFILE)

### Qu'est-ce qu'un ICP ?
L'ICP définit les caractéristiques de l'**entreprise** ou du **segment de marché** idéal pour votre offre. C'est une description factuelle et objective qui permet de qualifier rapidement si un prospect vaut la peine d'être approché.

### Structure d'un ICP B2B

#### 1. FIRMOGRAPHIQUES
**Secteur d'activité :**
- Industries principales (ex: SaaS, E-commerce, Industrie, Services)
- Sous-secteurs spécifiques
- Exclusions (secteurs non pertinents)

**Taille d'entreprise :**
- Effectifs : [X-Y] employés
- Chiffre d'affaires annuel : [X-Y] M€
- Taille de l'équipe concernée par votre solution

**Maturité :**
- Startup / Scale-up / PME établie / ETI / Grand compte
- Années d'existence
- Phase de croissance (seed, série A, rentable...)

**Localisation géographique :**
- Pays/régions ciblés
- Présence locale vs internationale
- Fuseaux horaires pertinents

#### 2. TECHNOGRAPHIQUES (si pertinent)
**Stack technique actuel :**
- CRM utilisé (Salesforce, HubSpot, Pipedrive...)
- Outils marketing (Mailchimp, ActiveCampaign...)
- Infrastructure (AWS, Azure...)
- Intégrations nécessaires

**Maturité digitale :**
- Niveau de digitalisation (faible/moyen/avancé)
- Appétence pour nouvelles technologies
- Budgets tech annuels

#### 3. COMPORTEMENTAUX
**Signaux d'achat :**
- Levée de fonds récente
- Recrutement en cours (postes spécifiques)
- Changement de direction
- Croissance rapide
- Expansion géographique
- Post LinkedIn révélateur

**Budget et processus d'achat :**
- Budget type pour votre catégorie de solution
- Cycle de vente moyen : [X] semaines/mois
- Nombre de décideurs impliqués
- Période d'achat privilégiée (T1, T4...)

#### 4. CRITÈRES DE QUALIFICATION (SCORING)
**Must-have (obligatoires) :**
- [ ] Critère 1
- [ ] Critère 2
- [ ] Critère 3

**Nice-to-have (bonus) :**
- [ ] Critère A
- [ ] Critère B

**Red flags (disqualification) :**
- ❌ Secteur exclu
- ❌ Budget insuffisant
- ❌ Concurrent direct

### Structure d'un ICP B2C

#### 1. DÉMOGRAPHIQUES
- Âge : [X-Y] ans
- Genre : H/F/Tous
- Situation familiale
- Niveau d'éducation
- CSP (Catégorie socio-professionnelle)
- Revenus : [X-Y]€/mois ou /an

#### 2. GÉOGRAPHIQUES
- Localisation (pays, région, ville)
- Type d'habitat (urbain/périurbain/rural)
- Mobilité

#### 3. PSYCHOGRAPHIQUES
- Style de vie
- Valeurs importantes
- Centres d'intérêt / Hobbies
- Aspirations
- Personnalité type

#### 4. COMPORTEMENTAUX
- Habitudes d'achat
- Canaux privilégiés
- Sensibilité prix
- Déclencheurs d'achat

## PARTIE 2 : PERSONA (BUYER PERSONA)

### Qu'est-ce qu'un Persona ?
Le persona donne vie à votre ICP en créant un profil **humanisé** et **narratif** d'un individu représentatif. C'est une personne fictive mais réaliste que vous pouvez visualiser.

### Template de Persona complet

---

## 👤 [PRÉNOM + NOM FICTIF]
**[Job Title]** chez [Type d'entreprise]

### Photo / Avatar
[Description visuelle ou image]

### Citation représentative
> "Une phrase qui résume sa vision ou préoccupation principale"

---

### 📋 INFORMATIONS GÉNÉRALES

**Âge :** [X] ans  
**Localisation :** [Ville, Pays]  
**Formation :** [Diplôme/Formation]  
**Ancienneté dans le poste :** [X] ans  
**Taille de l'équipe gérée :** [X] personnes  
**Salaire annuel :** [Fourchette] (si pertinent B2B)

---

### 💼 CONTEXTE PROFESSIONNEL

#### Responsabilités principales
1. [Responsabilité 1]
2. [Responsabilité 2]
3. [Responsabilité 3]

#### Objectifs professionnels (ce sur quoi il/elle est évalué·e)
- 🎯 [Objectif 1 - ex: Augmenter les ventes de 20%]
- 🎯 [Objectif 2 - ex: Réduire le taux de churn à <5%]
- 🎯 [Objectif 3 - ex: Optimiser les coûts opérationnels]

#### KPIs suivis
- [Métrique 1]
- [Métrique 2]
- [Métrique 3]

#### Outils utilisés quotidiennement
- [Outil 1]
- [Outil 2]
- [Outil 3]

---

### 😰 PAIN POINTS (PROBLÈMES RENCONTRÉS)

#### Problème #1 : [Titre du problème]
**Description :** [Explication détaillée du problème]  
**Impact :** [Conséquences négatives sur son travail/vie]  
**Fréquence :** [Quotidien / Hebdo / Mensuel]  
**Gravité :** 🔴 Critique / 🟠 Important / 🟡 Modéré

#### Problème #2 : [Titre]
**Description :**  
**Impact :**  
**Fréquence :**  
**Gravité :**

#### Problème #3 : [Titre]
**Description :**  
**Impact :**  
**Fréquence :**  
**Gravité :**

**💡 Insight clé :** [Le pain point principal qui rend votre solution indispensable]

---

### ✨ MOTIVATIONS & ASPIRATIONS

#### Motivations professionnelles
- ✅ [Motivation 1 - ex: Être reconnu comme expert]
- ✅ [Motivation 2 - ex: Évolution de carrière]
- ✅ [Motivation 3 - ex: Simplifier son quotidien]

#### Motivations personnelles (si B2C ou pertinent)
- 💚 [Motivation 1]
- 💚 [Motivation 2]

#### Ce qu'il/elle valorise dans une solution
1. **[Valeur 1]** - [Pourquoi c'est important]
2. **[Valeur 2]** - [Pourquoi c'est important]
3. **[Valeur 3]** - [Pourquoi c'est important]

---

### 🚫 OBJECTIONS & FREINS À L'ACHAT

#### Objections typiques
1. **"[Objection 1]"**  
   → Réponse suggérée : [Comment lever cette objection]

2. **"[Objection 2]"**  
   → Réponse suggérée :

3. **"[Objection 3]"**  
   → Réponse suggérée :

#### Freins décisionnels
- ⚠️ [Frein 1 - ex: Processus de validation long (3+ décideurs)]
- ⚠️ [Frein 2 - ex: Budget déjà alloué pour l'année]
- ⚠️ [Frein 3 - ex: Peur du changement / Résistance équipe]

---

### 🔍 PROCESSUS DE DÉCISION

#### Déclencheurs d'achat (qu'est-ce qui le pousse à chercher une solution ?)
1. [Déclencheur 1 - ex: Problème devenu trop coûteux]
2. [Déclencheur 2 - ex: Nouveau projet stratégique]
3. [Déclencheur 3 - ex: Recommandation d'un pair]

#### Parcours d'achat typique
**Phase 1 : Prise de conscience (Awareness)**
- Actions : [ex: Recherche Google, lecture blog, LinkedIn]
- Questions : [ex: "Comment améliorer X?"]
- Durée : [X] semaines

**Phase 2 : Considération**
- Actions : [ex: Comparaison solutions, demande démo]
- Questions : [ex: "Quelle solution choisir?"]
- Durée : [X] semaines

**Phase 3 : Décision**
- Actions : [ex: Négociation prix, validation interne]
- Questions : [ex: "ROI? Garanties?"]
- Durée : [X] semaines

#### Influenceurs dans la décision
- **Décideur final :** [Rôle - ex: CEO, CFO]
- **Prescripteurs :** [Rôles - ex: CTO recommande]
- **Utilisateurs finaux :** [Rôles - ex: Équipe marketing]
- **Blockers potentiels :** [Rôles - ex: DAF si pas de budget]

#### Budget disponible
- Fourchette : [X-Y]€
- Type de budget : CAPEX / OPEX
- Période de renouvellement : [Annuel / Pluriannuel]

---

### 📱 CANAUX DE COMMUNICATION PRIVILÉGIÉS

#### Où le trouver ?
- 📧 **Email :** [Pertinence - Haute/Moyenne/Faible]
- 💼 **LinkedIn :** [Pertinence + comportement sur la plateforme]
- 📞 **Téléphone :** [Pertinence]
- 🎤 **Événements :** [Types d'événements fréquentés]
- 📰 **Médias :** [Quels médias/blogs il lit]
- 🎙️ **Podcasts :** [Quels podcasts il écoute]

#### Ton et style de communication préféré
- Style : [Formel / Friendly / Technique / Business]
- Format : [Court et percutant / Détaillé / Visuel]
- Moments privilégiés : [Meilleurs jours/heures pour le contacter]

#### Mots-clés / Vocabulaire à utiliser
- ✅ Expressions qui résonnent : [ex: "ROI", "gain de temps", "scalable"]
- ❌ Termes à éviter : [ex: "révolutionnaire", jargon trop technique]

---

### 🎯 STRATÉGIE D'APPROCHE RECOMMANDÉE

#### Message d'accroche
**Angle à privilégier :**  
[ex: Parler de son pain point #1 immédiatement]

**Exemple de première phrase :**  
"[Prénom], j'ai vu que [contexte entreprise/post LinkedIn]. Beaucoup de [son titre] nous disent que [pain point]. C'est votre cas ?"

#### Proposition de valeur pour ce persona
**En 1 phrase :**  
[Votre solution] aide [Persona] à [bénéfice principal] en [différenciation clé], sans [objection principale].

**Exemple :**  
"Notre plateforme aide les Directeurs Marketing à générer 3x plus de leads qualifiés en automatisant la prospection LinkedIn, sans recruter."

#### Preuves sociales à mettre en avant
- [Type de preuve pertinente - ex: Cas client similaire]
- [Chiffres clés qui parlent à ce persona]
- [Certification/Label valorisant pour lui]

#### Content marketing adapté
**Formats préférés :**
- [Format 1 - ex: Webinar technique]
- [Format 2 - ex: Case study avec ROI chiffré]
- [Format 3 - ex: Checklist PDF]

**Sujets qui l'intéressent :**
1. [Sujet 1]
2. [Sujet 2]
3. [Sujet 3]

---

### 📊 UNE JOURNÉE TYPE

**8h00 :** [Activité]  
**9h00 :** [Activité]  
**12h00 :** [Activité]  
...  
**18h00 :** [Activité]

💡 **Insight :** [Quand et comment votre solution s'intègre dans sa journée]

---

### 🎭 PERSONA EN ACTION - SCÉNARIO D'USAGE

#### Situation
[Description d'une situation concrète où votre persona rencontre le problème]

#### Pensées
[Ce qu'il se dit intérieurement]

#### Émotions
[Ce qu'il ressent]

#### Actions
[Ce qu'il fait pour résoudre le problème]

#### Résultat avec votre solution
[Comment votre solution transforme cette expérience]

---

### ⚡ QUICK WINS POUR CONVAINCRE CE PERSONA

1. **[Quick Win 1]** - [Bénéfice rapide et tangible]
2. **[Quick Win 2]** - [Preuve de concept simple]
3. **[Quick Win 3]** - [Victoire rapide visible]

---

## TYPES DE PERSONAS À CRÉER

### Selon la complexité de vente

**Vente simple (1 décideur) :**
- 1-2 personas suffisent

**Vente complexe (comité de décision) :**
- **Economic Buyer** (celui qui signe)
- **Champion** (ambassadeur interne)
- **Technical Buyer** (valide la faisabilité)
- **End User** (utilisateur final)
- **Blocker** (peut bloquer la vente)

### Personas recommandés par industrie

**B2B SaaS :**
- CEO / Founder
- VP Sales / Marketing / Ops
- Manager opérationnel
- Utilisateur final

**E-commerce :**
- Gérant e-commerce
- Responsable acquisition
- Acheteur type (B2C)

**Consulting :**
- Dirigeant PME
- Directeur métier (RH, Finance, IT...)

**B2C :**
- 3-5 personas selon segments de clientèle

## MÉTHODOLOGIE DE CRÉATION

### Étape 1 : Collecter les informations

**Sources de données :**
- ✅ Interviews clients existants (meilleure source)
- ✅ Équipe commerciale (retours terrain)
- ✅ Analytics site web et CRM
- ✅ Réseaux sociaux (LinkedIn, groupes FB)
- ✅ Avis clients et tickets support
- ✅ Études de marché
- ✅ Concurrence (qui ciblent-ils ?)

**Questions à poser à vos meilleurs clients :**
1. Quel était votre principal problème avant de nous trouver ?
2. Qu'avez-vous essayé avant nous ?
3. Qu'est-ce qui vous a convaincu de nous choisir ?
4. Quelles étaient vos hésitations ?
5. Qui d'autre devait approuver la décision ?
6. Où avez-vous entendu parler de nous ?

### Étape 2 : Segmenter et prioriser

**Critères de priorisation :**
1. **Volume** : Combien de prospects correspondent ?
2. **Valeur** : Panier moyen / LTV
3. **Accessibilité** : Facilité à les toucher
4. **Conversion** : Taux de closing historique

**Action :** Créer 1 persona pour votre segment #1, puis itérer

### Étape 3 : Humaniser le persona

**Techniques :**
- Donner un prénom et nom fictif mémorable
- Trouver une vraie photo (banques d'images libres)
- Utiliser des citations réelles de clients
- Raconter une histoire de vie professionnelle

### Étape 4 : Valider et tester

**Checklist de validation :**
- [ ] Basé sur données réelles (pas juste intuitions)
- [ ] Assez spécifique pour être actionnable
- [ ] Partagé avec équipe commerciale
- [ ] Testé sur campagnes de prospection
- [ ] Itéré selon résultats

## WORKFLOW AVEC CLAUDE

### Format court (Persona Express)
**Commande :**
```
"Crée-moi 1 persona pour [votre offre]. 
Je cible [secteur/segment]. 
Format court (2 pages max)."
```

**Résultat :** Persona synthétique avec essentials

### Format complet (Persona Pro)
**Commande :**
```
"Crée-moi un persona complet pour [description offre].
Voici mes infos :
- Secteur : [X]
- Offre : [Y]
- Problème résolu : [Z]
- Budget client type : [€]
- Cas clients : [exemples]

Format : Document détaillé."
```

**Résultat :** Persona exhaustif selon template ci-dessus

### Générer plusieurs personas
**Commande :**
```
"Crée 3 personas pour ma solution [X] :
1. Décideur économique
2. Champion/Prescripteur  
3. Utilisateur final

Secteur : [Y]"
```

### Persona à partir de données clients
**Commande :**
```
"Voici les données de mes 10 meilleurs clients [CSV/liste].
Analyse et crée-moi 2 personas types."
```

### Affiner un persona existant
**Commande :**
```
"Voici mon persona actuel [coller].
Améliore la partie [pain points / objections / stratégie d'approche]."
```

## UTILISATION PRATIQUE DES PERSONAS

### Pour la prospection
- **LinkedIn :** Filtres de recherche = critères ICP
- **Cold email :** Personnalisation selon pain points
- **Appel :** Script adapté aux objections
- **Ciblage pub :** Audiences lookalike

### Pour le marketing de contenu
- **Blog :** Articles répondant aux questions du persona
- **Webinars :** Sujets qui l'intéressent
- **Lead magnets :** Formats qu'il préfère
- **Social media :** Ton et style adaptés

### Pour le sales
- **Pitch :** Bénéfices hiérarchisés par importance pour lui
- **Démo :** Features présentées dans son ordre de priorité
- **Proposition :** Arguments et preuves qui résonnent
- **Négociation :** Leviers de valeur spécifiques

### Pour le produit
- **Roadmap :** Prioriser features selon besoins persona
- **UX :** Parcours utilisateur adapté
- **Onboarding :** Quick wins du persona

## ERREURS À ÉVITER

❌ **Personas trop vagues**  
"Responsable marketing dans une PME" → Trop large, pas actionnable

❌ **Basés sur intuition uniquement**  
Valider avec données réelles

❌ **Trop nombreux**  
Commencer par 1-3 personas max, sinon dilution des efforts

❌ **Pas mis à jour**  
Réviser tous les 6-12 mois

❌ **Pas partagés avec l'équipe**  
Personas inutiles s'ils restent dans un tiroir

❌ **Confondre ICP et Persona**  
ICP = entreprise | Persona = individu

❌ **Caractéristiques superficielles**  
"Aime le café" → Inutile. Focus sur le professionnel.

## TEMPLATES DE LIVRABLES

### Fiche Persona 1 page (version print)
Format A4 recto avec essentiel visuel

### Persona slide PowerPoint
Pour présentation commerciale

### Persona Canvas
Format visuel type canvas Lean

### Persona CRM
Champs personnalisés dans votre CRM

## KPIs POUR MESURER L'IMPACT

**Indicateurs de succès :**
- 📈 Taux d'ouverture emails +X%
- 📈 Taux de réponse prospection +X%
- 📈 Taux de conversion démo → closing +X%
- 📈 Cycle de vente -X jours
- 📈 Taux de qualification leads +X%

## RESSOURCES COMPLÉMENTAIRES

**Questions JTBD (Jobs To Be Done) :**
1. Quel "job" le client cherche-t-il à accomplir ?
2. Qu'utilise-t-il aujourd'hui pour y arriver ?
3. Qu'est-ce qui ne fonctionne pas dans sa solution actuelle ?

**Framework JTBD :**
"Quand [situation], je veux [motivation], pour [résultat attendu]."

**Exemple :**  
"Quand je dois recruter rapidement, je veux filtrer 100 CVs en 1h, pour ne pas retarder le projet."

---

## COMMANDES TYPES POUR CLAUDE

```
"Crée 1 persona complet pour une solution de [X] qui cible [secteur Y]"

"Génère 3 personas : décideur, prescripteur, utilisateur pour [offre]"

"Analyse ces données clients et crée 2 personas types"

"Améliore ce persona avec plus de détails sur pain points et objections"

"Crée un ICP + 1 persona pour du B2B SaaS dans [secteur]"

"Format visuel : Persona sur 1 slide PowerPoint"

"Donne-moi les questions d'interview à poser à mes clients pour créer mes personas"
```

---

**FIN DU SKILL ICP-PERSONA-GENERATOR**

Ce skill permet de créer des profils clients idéaux scientifiques et actionnables qui transforment vos efforts commerciaux et marketing en actions ciblées et efficaces.

#!/bin/bash
# Script to generate all visuals for competitive analysis
# Usage: ./generate_all_visuals.sh [input_file] [output_directory]

# Default values
INPUT_FILE="${1:-assets/example_saas_analysis.json}"
OUTPUT_DIR="${2:-analysis_output}"

echo "🚀 Génération complète de l'analyse concurrentielle"
echo "=================================================="
echo ""
echo "📁 Fichier d'entrée : $INPUT_FILE"
echo "📁 Répertoire de sortie : $OUTPUT_DIR"
echo ""

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo "⚠️  Fichier d'entrée non trouvé : $INPUT_FILE"
    echo "📝 Utilisation de données d'exemple par défaut..."
    INPUT_FILE=""
fi

# Matrices de positionnement
echo "📊 1/4 - Génération des matrices de positionnement..."
if [ -z "$INPUT_FILE" ]; then
    python3 scripts/generate_positioning_matrix.py \
        --output "$OUTPUT_DIR" \
        --format png,svg
else
    python3 scripts/generate_positioning_matrix.py \
        --input "$INPUT_FILE" \
        --output "$OUTPUT_DIR" \
        --format png,svg
fi
echo "✅ Matrices de positionnement générées"
echo ""

# Tableaux comparatifs
echo "📊 2/4 - Génération des tableaux comparatifs..."
if [ -z "$INPUT_FILE" ]; then
    python3 scripts/generate_comparison_table.py \
        --output "$OUTPUT_DIR" \
        --format markdown,csv,excel
else
    python3 scripts/generate_comparison_table.py \
        --input "$INPUT_FILE" \
        --output "$OUTPUT_DIR" \
        --format markdown,csv,excel
fi
echo "✅ Tableaux comparatifs générés"
echo ""

# Matrices d'opportunités
echo "📊 3/4 - Génération des matrices d'opportunités..."
if [ -z "$INPUT_FILE" ]; then
    python3 scripts/generate_opportunity_matrix.py \
        --output "$OUTPUT_DIR" \
        --format png,svg
else
    python3 scripts/generate_opportunity_matrix.py \
        --input "$INPUT_FILE" \
        --output "$OUTPUT_DIR" \
        --format png,svg
fi
echo "✅ Matrices d'opportunités générées"
echo ""

# Battle cards
echo "📊 4/4 - Génération des battle cards..."
if [ -z "$INPUT_FILE" ]; then
    python3 scripts/generate_battle_cards.py \
        --output "$OUTPUT_DIR" \
        --format pdf,png \
        --combined
else
    python3 scripts/generate_battle_cards.py \
        --input "$INPUT_FILE" \
        --output "$OUTPUT_DIR" \
        --format pdf,png \
        --combined
fi
echo "✅ Battle cards générées"
echo ""

# Summary
echo "=================================================="
echo "✅ Génération terminée avec succès !"
echo ""
echo "📂 Tous les fichiers ont été générés dans : $OUTPUT_DIR"
echo ""
echo "📋 Fichiers générés :"
echo "   Matrices :"
echo "   - matrix_price_value.png/svg"
echo "   - matrix_custom_axes.png/svg"
echo "   - radar_positioning.png/svg"
echo ""
echo "   Tableaux :"
echo "   - comparison_table.md"
echo "   - comparison_data.csv"
echo "   - comparison_analysis.xlsx"
echo ""
echo "   Opportunités :"
echo "   - opportunity_matrix.png/svg"
echo "   - opportunity_scores.png/svg"
echo "   - priority_ranking.md"
echo ""
echo "   Battle cards :"
echo "   - battlecard_*.pdf"
echo "   - battlecard_*.png"
echo "   - battlecards_all.pdf"
echo ""
echo "🎉 Votre analyse concurrentielle est prête !"

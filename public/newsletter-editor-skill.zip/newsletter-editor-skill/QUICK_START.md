# Démarrage rapide — Newsletter Editor Skill

## Étape 1 — Installer le skill

Copie `SKILL.md` dans `~/.claude/commands/newsletter.md`

## Étape 2 — Rédiger ta newsletter

Dans ton projet Claude, rédige ta newsletter normalement avec ton assistant.

## Étape 3 — Générer le JSON

Une fois le contenu validé, tape dans Claude Code :

```
/newsletter [colle ton texte ici]
```

## Étape 4 — Importer dans l'éditeur

1. Ouvre ton éditeur de newsletter sur `http://localhost:5173`
2. Clique **"Importer depuis Claude"** (bas de la colonne gauche)
3. Colle le JSON généré
4. Clique **Importer**

## Étape 5 — Exporter

- **ZIP** → HTML + JSON de sauvegarde
- **HTML** → fichier seul pour Mailchimp, Brevo, etc.
- **Copier** → HTML dans le presse-papiers

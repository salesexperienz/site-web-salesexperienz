#!/usr/bin/env python3
"""
Generate battle cards for competitive analysis.

This script creates visual battle cards in multiple formats:
- PDF formatted battle cards (one per competitor)
- PNG images for digital use
- Combined PDF with all battle cards

Usage:
    python generate_battle_cards.py --output analysis_output --format pdf,png
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.backends.backend_pdf import PdfPages
import textwrap


def wrap_text(text: str, width: int = 60) -> str:
    """Wrap text to specified width."""
    return '\n'.join(textwrap.wrap(text, width=width))


def create_battle_card_visual(
    competitor: Dict[str, any],
    fig: plt.Figure,
    ax: plt.Axes
) -> None:
    """
    Create a visual battle card for a single competitor.

    Args:
        competitor: Competitor data dictionary
        fig: Matplotlib figure
        ax: Matplotlib axes
    """
    # Clear axes
    ax.clear()
    ax.axis('off')
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 12)

    # Header with title
    name = competitor.get('name', 'Concurrent')
    header_rect = patches.Rectangle((0, 11), 10, 1, linewidth=2,
                                   edgecolor='black', facecolor='#FF6B6B')
    ax.add_patch(header_rect)
    ax.text(5, 11.5, f'🥊 BATTLE CARD : VS {name.upper()}',
           ha='center', va='center', fontsize=18, fontweight='bold', color='white')

    # Section 1: Key Info (top)
    y_pos = 10.5
    ax.text(0.2, y_pos, 'À SAVOIR', fontsize=12, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='lightblue'))

    info_items = [
        f"Taille : {competitor.get('size', 'N/A')}",
        f"Fondation : {competitor.get('founded', 'N/A')}",
        f"Cible principale : {competitor.get('target', 'N/A')}",
        f"Prix moyen : {competitor.get('pricing', 'N/A')}"
    ]

    y_pos -= 0.4
    for item in info_items:
        ax.text(0.3, y_pos, item, fontsize=9, verticalalignment='top')
        y_pos -= 0.3

    # Section 2: Strengths
    y_pos -= 0.3
    ax.text(0.2, y_pos, 'LEURS FORCES (à reconnaître)', fontsize=12, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='lightgreen'))

    strengths = competitor.get('strengths', [])
    y_pos -= 0.4
    for i, strength in enumerate(strengths[:3], 1):
        wrapped = wrap_text(f"✅ {strength}", 80)
        ax.text(0.3, y_pos, wrapped, fontsize=9, verticalalignment='top')
        y_pos -= 0.35

    # Section 3: Weaknesses
    y_pos -= 0.3
    ax.text(0.2, y_pos, 'LEURS FAIBLESSES (à exploiter)', fontsize=12, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='#FFE66D'))

    weaknesses = competitor.get('weaknesses', [])
    y_pos -= 0.4
    for i, weakness in enumerate(weaknesses[:3], 1):
        wrapped = wrap_text(f"❌ {weakness}", 80)
        ax.text(0.3, y_pos, wrapped, fontsize=9, verticalalignment='top')
        y_pos -= 0.35

    # Section 4: Key Objections
    y_pos -= 0.3
    ax.text(0.2, y_pos, 'OBJECTIONS TYPIQUES & RÉPONSES', fontsize=12, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='#FFB6C1'))

    objections = competitor.get('objections', [])
    y_pos -= 0.4
    for obj in objections[:2]:
        objection_text = obj.get('objection', '')
        response = obj.get('response', '')

        # Objection
        wrapped_obj = wrap_text(f"❓ {objection_text}", 80)
        ax.text(0.3, y_pos, wrapped_obj, fontsize=8, fontweight='bold',
               verticalalignment='top')
        y_pos -= 0.25

        # Response
        wrapped_resp = wrap_text(f"→ {response}", 80)
        ax.text(0.5, y_pos, wrapped_resp, fontsize=8, style='italic',
               verticalalignment='top')
        y_pos -= 0.4

    # Section 5: When to recommend
    y_pos -= 0.2
    ax.text(0.2, y_pos, 'QUAND LES RECOMMANDER (fair play)', fontsize=11, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='#DDA0DD'))

    when_them = competitor.get('when_recommend_them', 'N/A')
    y_pos -= 0.3
    wrapped_when_them = wrap_text(when_them, 80)
    ax.text(0.3, y_pos, wrapped_when_them, fontsize=8, verticalalignment='top')

    # Section 6: When to recommend us
    y_pos -= len(wrapped_when_them.split('\n')) * 0.15 + 0.2
    ax.text(0.2, y_pos, 'QUAND NOUS RECOMMANDER', fontsize=11, fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3', facecolor='#90EE90'))

    when_us = competitor.get('when_recommend_us', [])
    y_pos -= 0.3
    for criteria in when_us[:3]:
        wrapped_crit = wrap_text(f"✅ {criteria}", 80)
        ax.text(0.3, y_pos, wrapped_crit, fontsize=8, verticalalignment='top')
        y_pos -= 0.25

    # Footer
    footer_rect = patches.Rectangle((0, 0), 10, 0.4, linewidth=1,
                                   edgecolor='black', facecolor='#E0E0E0')
    ax.add_patch(footer_rect)
    ax.text(5, 0.2, 'Battle Card - Analyse Concurrentielle Express',
           ha='center', va='center', fontsize=8, style='italic')


def generate_single_battlecard_pdf(
    competitor: Dict[str, any],
    output_path: Path
) -> None:
    """Generate a single PDF battle card."""
    name = competitor.get('name', 'Concurrent')
    safe_name = name.replace(' ', '_').replace('/', '_')
    output_file = output_path / f'battlecard_{safe_name}.pdf'

    fig = plt.figure(figsize=(8.5, 11))  # Letter size
    ax = fig.add_subplot(111)

    create_battle_card_visual(competitor, fig, ax)

    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()

    print(f"✅ Battle card PDF générée : {output_file}")


def generate_single_battlecard_png(
    competitor: Dict[str, any],
    output_path: Path
) -> None:
    """Generate a single PNG battle card."""
    name = competitor.get('name', 'Concurrent')
    safe_name = name.replace(' ', '_').replace('/', '_')
    output_file = output_path / f'battlecard_{safe_name}.png'

    fig = plt.figure(figsize=(8.5, 11))  # Letter size
    ax = fig.add_subplot(111)

    create_battle_card_visual(competitor, fig, ax)

    plt.tight_layout()
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    plt.close()

    print(f"✅ Battle card PNG générée : {output_file}")


def generate_combined_battlecards_pdf(
    competitors: List[Dict[str, any]],
    output_path: Path
) -> None:
    """Generate a combined PDF with all battle cards."""
    output_file = output_path / 'battlecards_all.pdf'

    with PdfPages(output_file) as pdf:
        for competitor in competitors:
            fig = plt.figure(figsize=(8.5, 11))  # Letter size
            ax = fig.add_subplot(111)

            create_battle_card_visual(competitor, fig, ax)

            plt.tight_layout()
            pdf.savefig(fig, dpi=300, bbox_inches='tight')
            plt.close()

    print(f"✅ PDF combiné de toutes les battle cards généré : {output_file}")


def main():
    """Main function to generate battle cards."""
    parser = argparse.ArgumentParser(
        description='Generate battle cards for competitive analysis'
    )
    parser.add_argument('--input', type=str, default='battlecards_data.json',
                       help='Input JSON file with competitor data')
    parser.add_argument('--output', type=str, default='output',
                       help='Output directory for generated files')
    parser.add_argument('--format', type=str, default='pdf,png',
                       help='Output formats (pdf, png), comma-separated')
    parser.add_argument('--combined', action='store_true',
                       help='Generate combined PDF with all battle cards')

    args = parser.parse_args()

    # Create output directory
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Load competitor data
    input_file = Path(args.input)
    if input_file.exists():
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            competitors = data.get('competitors', [])
    else:
        # Example data if no input file
        print("⚠️  Fichier d'entrée non trouvé. Utilisation de données d'exemple.")
        competitors = [
            {
                'name': 'Concurrent A (Leader)',
                'size': '500+ employés, €100M+ CA',
                'founded': '2010, Silicon Valley',
                'target': 'Grandes entreprises internationales',
                'pricing': '24-50€/user/mois',
                'strengths': [
                    'Fonctionnalités très complètes et matures',
                    'Fiabilité éprouvée avec 99.9% uptime',
                    'Grande notoriété et références prestigieuses'
                ],
                'weaknesses': [
                    'Prix élevé, hors budget pour PME',
                    'Complexité importante, courbe d\'apprentissage longue',
                    'Support client limité en français, délais 24-48h'
                ],
                'objections': [
                    {
                        'objection': 'Mais Concurrent A a plus de fonctionnalités',
                        'response': 'C\'est vrai. Maintenant, 70% de leurs clients n\'utilisent que 30% des fonctionnalités. Nous nous concentrons sur l\'essentiel, ce qui permet à nos clients d\'être opérationnels en 2 jours vs 2 semaines.'
                    },
                    {
                        'objection': 'Concurrent A est le leader du marché',
                        'response': 'Absolument. Être leader signifie aussi servir tout le monde, créant des compromis. Pour les PME françaises, nous sommes spécialisés. Par exemple, notre support FR répond en <2h vs 24-48h chez eux.'
                    }
                ],
                'when_recommend_them': 'Concurrent A est excellent si vous êtes une grande entreprise internationale avec budget conséquent, équipe IT dédiée, et besoin de fonctionnalités très avancées.',
                'when_recommend_us': [
                    'Vous êtes une PME de 5-50 employés',
                    'Vous cherchez une solution opérationnelle rapidement',
                    'Le support en français est critique pour vous'
                ]
            },
            {
                'name': 'Concurrent B (Low-cost)',
                'size': '50-100 employés, startup',
                'founded': '2018, France',
                'target': 'Startups et TPE',
                'pricing': '8-15€/user/mois, freemium',
                'strengths': [
                    'Prix très attractif avec version gratuite',
                    'Interface simple et intuitive',
                    'Adoption rapide, pas de formation nécessaire'
                ],
                'weaknesses': [
                    'Fonctionnalités basiques, limites rapidement atteintes',
                    'Support minimal (FAQ et email uniquement)',
                    'Fiabilité perfectible, bugs fréquents reportés'
                ],
                'objections': [
                    {
                        'objection': 'Concurrent B est moins cher',
                        'response': 'Sur le prix d\'entrée, oui. Par contre, en croissant vous devrez vite passer au plan premium (25€/user) pour débloquer les limites. Avec nous à 12€, vous avez tout inclus dès le départ, et notre support évite les pertes de productivité.'
                    },
                    {
                        'objection': 'Concurrent B a une version gratuite',
                        'response': 'C\'est vrai et c\'est parfait pour tester. Maintenant, le gratuit est limité à 3 users et fonctionnalités de base. Si vous êtes sérieux sur votre croissance, vous investirez rapidement. Nous offrons 14 jours d\'essai complet pour que vous testiez la vraie valeur.'
                    }
                ],
                'when_recommend_them': 'Concurrent B est parfait si vous êtes une très petite équipe (<5 personnes), budget ultra-serré, et besoins basiques de gestion.',
                'when_recommend_us': [
                    'Vous avez besoin de fonctionnalités avancées',
                    'La fiabilité et le support sont critiques',
                    'Vous cherchez un partenaire sur le long terme'
                ]
            }
        ]

    # Generate battle cards
    formats = [f.strip() for f in args.format.split(',')]

    print(f"\n🥊 Génération des battle cards...\n")

    for competitor in competitors:
        for fmt in formats:
            if fmt == 'pdf':
                generate_single_battlecard_pdf(competitor, output_path)
            elif fmt == 'png':
                generate_single_battlecard_png(competitor, output_path)

    # Generate combined PDF if requested
    if args.combined or 'pdf' in formats:
        generate_combined_battlecards_pdf(competitors, output_path)

    print(f"\n✅ Toutes les battle cards ont été générées dans : {output_path}")
    print(f"\n💡 Pour personnaliser, créez un fichier '{args.input}' avec vos données.")


if __name__ == '__main__':
    main()

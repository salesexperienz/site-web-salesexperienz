# Competitive Analysis Express Skill

Analyse concurrentielle rapide avec recherche web automatique pour comparer offres, identifier gaps de marché et créer matrices de positionnement différenciantes.

## 📋 Vue d'ensemble

Ce skill permet de réaliser en 15-20 minutes une analyse concurrentielle complète qui produit :

- ✅ Tableau comparatif multi-critères (Markdown, CSV, Excel)
- ✅ Matrices de positionnement visuelles (Prix/Valeur, axes stratégiques, radar)
- ✅ Identification des opportunités de marché (angles morts, segments sous-servis)
- ✅ Battle cards professionnelles pour l'équipe commerciale
- ✅ Plan d'action priorisé avec quick wins

## 🎯 Quand utiliser ce skill

- Lancer une nouvelle offre sur un marché existant
- Repositionner son offre face à la concurrence
- Identifier des opportunités de différenciation
- Préparer une stratégie commerciale ou marketing
- Créer des battle cards pour l'équipe de vente
- Préparer une levée de fonds ou un pitch investisseur

## 🚀 Démarrage rapide

### 1. Importer le skill

Copiez le dossier `competitive-analysis-express-SKILL` dans votre environnement Claude Code ou importez le fichier `.zip` dans Claude.ai.

### 2. Lancer l'analyse

Invoquez le skill avec :

```
/competitive-analysis-express

ou

"Fais-moi une analyse concurrentielle express pour :
- Mon offre : [description]
- Secteur : [industrie]
- Concurrents : [liste]"
```

### 3. Répondre aux questions

Le skill vous posera 4 questions essentielles :
1. Quelle est votre offre ?
2. Quel est votre secteur d'activité ?
3. Qui sont vos 3-5 principaux concurrents ?
4. Avez-vous des informations spécifiques déjà connues ?

### 4. Récupérer vos visuels

Le skill génère automatiquement tous les documents et visuels dont vous avez besoin.

## 📊 Scripts Python disponibles

Le skill inclut 4 scripts Python pour générer des visuels professionnels :

### 1. Matrices de positionnement

```bash
python scripts/generate_positioning_matrix.py \
  --output analysis_output \
  --format png,svg
```

Génère :
- Matrice Prix vs Valeur
- Matrice axes personnalisés
- Graphique radar multi-critères

### 2. Tableaux comparatifs

```bash
python scripts/generate_comparison_table.py \
  --output analysis_output \
  --format markdown,csv,excel
```

Génère :
- Tableau Markdown formaté
- Export CSV
- Fichier Excel multi-onglets

### 3. Matrices d'opportunités

```bash
python scripts/generate_opportunity_matrix.py \
  --output analysis_output \
  --format png,svg
```

Génère :
- Matrice Impact vs Facilité
- Graphique de scoring
- Classement de priorités

### 4. Battle cards visuelles

```bash
python scripts/generate_battle_cards.py \
  --output analysis_output \
  --format pdf,png \
  --combined
```

Génère :
- Battle card PDF par concurrent
- Battle card PNG par concurrent
- PDF combiné de toutes les battle cards

## 📁 Structure du skill

```
competitive-analysis-express-SKILL/
├── SKILL.md                          # Instructions principales du skill
├── README.md                         # Ce fichier
├── scripts/                          # Scripts Python pour visuels
│   ├── generate_positioning_matrix.py
│   ├── generate_comparison_table.py
│   ├── generate_opportunity_matrix.py
│   └── generate_battle_cards.py
├── references/                       # Documentation détaillée
│   └── scripts_documentation.md
└── assets/                          # Templates JSON
    ├── competitors_data_template.json
    ├── opportunities_data_template.json
    └── battlecards_data_template.json
```

## 🔧 Installation des dépendances

Pour utiliser les scripts Python :

```bash
pip install matplotlib numpy pandas openpyxl
```

## 💡 Exemples d'utilisation

### Analyse simple

```
"Analyse mes 3 principaux concurrents [A, B, C] et identifie les opportunités de marché non-exploitées"
```

### Avec données JSON personnalisées

1. Copiez un template depuis `assets/`
2. Remplissez avec vos données
3. Lancez le script correspondant :

```bash
python scripts/generate_positioning_matrix.py \
  --input mes_donnees.json \
  --output mon_analyse
```

### Mise à jour d'une analyse existante

```
"Voici mon analyse concurrentielle d'il y a 6 mois [upload]. Mets-la à jour avec les évolutions récentes"
```

## 🎨 Sorties générées

### Documents texte
- **Rapport Markdown complet** : Analyse structurée avec executive summary
- **Tableaux CSV** : Données exploitables dans Excel/Google Sheets
- **Fichier Excel multi-onglets** : Comparaison, Scoring, Forces-Faiblesses, Synthèse

### Visuels
- **Matrices PNG/SVG** : Prix vs Valeur, axes stratégiques, opportunités
- **Graphiques radar** : Positionnement multi-critères
- **Battle cards PDF** : Prêtes à imprimer et distribuer

### Plan d'action
- **Quick wins** (0-3 mois) : Actions immédiates à fort impact
- **Stratégie moyen terme** (3-12 mois) : Positionnement à construire
- **Veille concurrentielle** : Alertes et signaux à surveiller

## 🔗 Intégration avec autres skills

Ce skill s'intègre avec :

- **ocean-bleu-skills** : Transformation des gaps en stratégie Océan Bleu
- **ICP-persona-generator** : Analyse par persona
- **sales-call-script-generator** : Scripts d'appel avec arguments différenciants

## 📖 Documentation complète

Consultez :
- **SKILL.md** : Méthodologie complète et workflow détaillé
- **references/scripts_documentation.md** : Documentation des scripts Python
- **assets/*.json** : Templates pour vos données

## 🆘 Support

### Problèmes courants

**Les scripts ne fonctionnent pas**
→ Vérifiez l'installation des dépendances : `pip install matplotlib numpy pandas openpyxl`

**Erreurs de caractères spéciaux**
→ Assurez-vous que vos fichiers JSON sont encodés en UTF-8

**Visuels de mauvaise qualité**
→ Augmentez le DPI : `--format png` génère du 300 DPI par défaut

### Tester avec données d'exemple

Tous les scripts fonctionnent sans fichier d'entrée et génèrent des exemples :

```bash
python scripts/generate_positioning_matrix.py --output test
```

## 📝 Licence

Ce skill fait partie de la Claude Skills Factory.

---

**Dernière mise à jour** : 2025-01-25
**Version** : 1.0.0

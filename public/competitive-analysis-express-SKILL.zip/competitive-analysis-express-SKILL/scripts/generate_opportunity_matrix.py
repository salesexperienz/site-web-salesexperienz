#!/usr/bin/env python3
"""
Generate opportunity matrices for competitive analysis.

This script creates visual opportunity matrices:
- Impact vs Ease 2x2 matrix
- Opportunity scoring bar chart
- Priority ranking table

Usage:
    python generate_opportunity_matrix.py --output analysis_output --format png,svg
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np


def create_opportunity_matrix(
    opportunities: List[Dict[str, any]],
    output_path: Path,
    format: str = "png"
) -> None:
    """
    Create an Impact vs Ease 2x2 opportunity matrix.

    Args:
        opportunities: List of opportunity data with 'name', 'impact', 'ease'
        output_path: Directory to save the output file
        format: Image format ('png' or 'svg')
    """
    fig, ax = plt.subplots(figsize=(14, 10))

    # Set up the plot
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_xlabel('Facilité d\'exécution (0=Difficile, 10=Facile)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Impact sur le marché (0=Faible, 10=Élevé)', fontsize=14, fontweight='bold')
    ax.set_title('MATRICE DE PRIORISATION DES OPPORTUNITÉS\nImpact vs Facilité d\'exécution',
                fontsize=16, fontweight='bold', pad=20)

    # Add colored quadrant backgrounds
    # Low priority (bottom-left)
    rect1 = patches.Rectangle((0, 0), 5, 5, linewidth=0,
                              edgecolor='none', facecolor='lightcoral', alpha=0.2)
    ax.add_patch(rect1)

    # Medium priority (bottom-right)
    rect2 = patches.Rectangle((5, 0), 5, 5, linewidth=0,
                              edgecolor='none', facecolor='lightyellow', alpha=0.3)
    ax.add_patch(rect2)

    # Medium-high priority (top-left)
    rect3 = patches.Rectangle((0, 5), 5, 5, linewidth=0,
                              edgecolor='none', facecolor='lightblue', alpha=0.3)
    ax.add_patch(rect3)

    # High priority (top-right)
    rect4 = patches.Rectangle((5, 5), 5, 5, linewidth=0,
                              edgecolor='none', facecolor='lightgreen', alpha=0.4)
    ax.add_patch(rect4)

    # Add quadrant labels
    ax.text(2.5, 7.5, '🥈 PRIORITÉ 2\n(Investir)\nImpact élevé\nDifficile',
            ha='center', va='center', fontsize=12, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='lightblue', alpha=0.7))

    ax.text(7.5, 7.5, '🥇 PRIORITÉ 1\n(Quick wins)\nImpact élevé\nFacile',
            ha='center', va='center', fontsize=12, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='lightgreen', alpha=0.8))

    ax.text(2.5, 2.5, '❌ IGNORER\n(Pas prioritaire)\nFaible impact\nDifficile',
            ha='center', va='center', fontsize=12, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='lightcoral', alpha=0.7))

    ax.text(7.5, 2.5, '🥉 PRIORITÉ 3\n(Considérer)\nFaible impact\nFacile',
            ha='center', va='center', fontsize=12, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.5', facecolor='lightyellow', alpha=0.8))

    # Add grid
    ax.grid(True, alpha=0.3, linestyle='--', zorder=0)

    # Plot opportunities
    colors = plt.cm.tab10(np.linspace(0, 1, len(opportunities)))

    for i, opp in enumerate(opportunities):
        impact = opp.get('impact', 5)
        ease = opp.get('ease', 5)
        name = opp.get('name', f'Opportunité {i+1}')
        score = opp.get('score', 5)

        # Size based on score
        size = 200 + (score * 50)

        # Plot point
        ax.scatter(ease, impact, s=size, c=[colors[i]], marker='o',
                  edgecolors='black', linewidths=2, alpha=0.7,
                  label=f'{name} (Score: {score}/10)', zorder=5)

        # Add label with arrow
        ax.annotate(name, (ease, impact),
                   xytext=(15, 15), textcoords='offset points',
                   fontsize=9, fontweight='bold',
                   bbox=dict(boxstyle='round,pad=0.4', facecolor=colors[i], alpha=0.6),
                   arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0.3',
                                 color='black', lw=1.5))

    # Add reference lines
    ax.axhline(y=5, color='gray', linestyle='-', linewidth=2, alpha=0.6, zorder=1)
    ax.axvline(x=5, color='gray', linestyle='-', linewidth=2, alpha=0.6, zorder=1)

    # Add legend
    ax.legend(loc='upper left', fontsize=9, framealpha=0.9, ncol=1)

    plt.tight_layout()

    # Save the figure
    output_file = output_path / f'opportunity_matrix.{format}'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"✅ Matrice d'opportunités générée : {output_file}")
    plt.close()


def create_scoring_chart(
    opportunities: List[Dict[str, any]],
    output_path: Path,
    format: str = "png"
) -> None:
    """
    Create a bar chart showing opportunity scores.

    Args:
        opportunities: List of opportunity data with 'name', 'score', scoring breakdown
        output_path: Directory to save the output file
        format: Image format ('png' or 'svg')
    """
    # Sort opportunities by total score
    sorted_opps = sorted(opportunities, key=lambda x: x.get('score', 0), reverse=True)

    names = [opp.get('name', f'Opp {i+1}') for i, opp in enumerate(sorted_opps)]

    # Extract scoring components
    impact_scores = [opp.get('impact_score', 0) for opp in sorted_opps]
    ease_scores = [opp.get('ease_score', 0) for opp in sorted_opps]
    diff_scores = [opp.get('differentiation_score', 0) for opp in sorted_opps]
    timing_scores = [opp.get('timing_score', 0) for opp in sorted_opps]

    # Create figure
    fig, ax = plt.subplots(figsize=(14, 8))

    # Set up bar positions
    x = np.arange(len(names))
    width = 0.6

    # Create stacked bars
    p1 = ax.barh(x, impact_scores, width, label='Impact marché (/3)', color='#FF6B6B')
    p2 = ax.barh(x, ease_scores, width, left=impact_scores, label='Facilité exécution (/3)', color='#4ECDC4')
    p3 = ax.barh(x, diff_scores, width, left=np.array(impact_scores)+np.array(ease_scores),
                label='Différenciation (/2)', color='#95E1D3')
    p4 = ax.barh(x, timing_scores, width,
                left=np.array(impact_scores)+np.array(ease_scores)+np.array(diff_scores),
                label='Timing (/2)', color='#FFE66D')

    # Customize the plot
    ax.set_ylabel('Opportunités', fontsize=12, fontweight='bold')
    ax.set_xlabel('Score total (/10)', fontsize=12, fontweight='bold')
    ax.set_title('SCORING DES OPPORTUNITÉS\nDécomposition par critère',
                fontsize=16, fontweight='bold', pad=20)
    ax.set_yticks(x)
    ax.set_yticklabels(names, fontsize=10)
    ax.set_xlim(0, 10)
    ax.set_xticks(range(11))
    ax.legend(loc='lower right', fontsize=10, framealpha=0.9)
    ax.grid(axis='x', alpha=0.3, linestyle='--')

    # Add total score labels
    for i, opp in enumerate(sorted_opps):
        total = opp.get('score', 0)
        ax.text(total + 0.2, i, f'{total:.1f}/10',
               va='center', fontweight='bold', fontsize=10)

    plt.tight_layout()

    # Save the figure
    output_file = output_path / f'opportunity_scores.{format}'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"✅ Graphique de scoring généré : {output_file}")
    plt.close()


def create_priority_ranking_md(
    opportunities: List[Dict[str, any]],
    output_path: Path
) -> None:
    """
    Create a markdown table with priority ranking.

    Args:
        opportunities: List of opportunity data
        output_path: Directory to save the output file
    """
    output_file = output_path / 'priority_ranking.md'

    # Sort by score
    sorted_opps = sorted(opportunities, key=lambda x: x.get('score', 0), reverse=True)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# CLASSEMENT DES OPPORTUNITÉS PAR PRIORITÉ\n\n")
        f.write("*Généré automatiquement*\n\n")

        # Create table
        f.write("| Rang | Opportunité | Score | Impact | Facilité | Différenciation | Timing | Priorité |\n")
        f.write("|------|-------------|-------|--------|----------|-----------------|--------|----------|\n")

        for i, opp in enumerate(sorted_opps):
            rank = i + 1
            name = opp.get('name', 'N/A')
            score = opp.get('score', 0)
            impact = opp.get('impact_score', 0)
            ease = opp.get('ease_score', 0)
            diff = opp.get('differentiation_score', 0)
            timing = opp.get('timing_score', 0)

            # Determine priority level
            if score >= 8:
                priority = '🥇 PRIORITÉ 1'
            elif score >= 6:
                priority = '🥈 PRIORITÉ 2'
            elif score >= 4:
                priority = '🥉 PRIORITÉ 3'
            else:
                priority = '❌ Ignorer'

            f.write(f"| {rank} | **{name}** | **{score:.1f}/10** | {impact}/3 | {ease}/3 | {diff}/2 | {timing}/2 | {priority} |\n")

        # Add scoring legend
        f.write("\n\n## Légende du scoring\n\n")
        f.write("**Calcul du score total (/10) :**\n")
        f.write("- Impact marché : 0-3 points\n")
        f.write("- Facilité d'exécution : 0-3 points\n")
        f.write("- Différenciation créée : 0-2 points\n")
        f.write("- Timing (momentum) : 0-2 points\n\n")

        f.write("**Niveaux de priorité :**\n")
        f.write("- 🥇 **PRIORITÉ 1** (8-10/10) : Quick wins à implémenter immédiatement\n")
        f.write("- 🥈 **PRIORITÉ 2** (6-8/10) : Opportunités à fort potentiel nécessitant investissement\n")
        f.write("- 🥉 **PRIORITÉ 3** (4-6/10) : À considérer selon ressources disponibles\n")
        f.write("- ❌ **Ignorer** (<4/10) : Faible ROI, pas prioritaire\n")

    print(f"✅ Classement des priorités généré : {output_file}")


def main():
    """Main function to generate opportunity matrices."""
    parser = argparse.ArgumentParser(
        description='Generate opportunity matrices for competitive analysis'
    )
    parser.add_argument('--input', type=str, default='opportunities_data.json',
                       help='Input JSON file with opportunity data')
    parser.add_argument('--output', type=str, default='output',
                       help='Output directory for generated files')
    parser.add_argument('--format', type=str, default='png',
                       help='Image format (png or svg), comma-separated for multiple')

    args = parser.parse_args()

    # Create output directory
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Load opportunity data
    input_file = Path(args.input)
    if input_file.exists():
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            opportunities = data.get('opportunities', [])
    else:
        # Example data if no input file
        print("⚠️  Fichier d'entrée non trouvé. Utilisation de données d'exemple.")
        opportunities = [
            {
                'name': 'Support FR premium',
                'impact': 8.5,
                'ease': 7,
                'impact_score': 2.8,
                'ease_score': 2.3,
                'differentiation_score': 2,
                'timing_score': 1.8,
                'score': 8.9
            },
            {
                'name': 'Onboarding personnalisé',
                'impact': 7,
                'ease': 8,
                'impact_score': 2.3,
                'ease_score': 2.7,
                'differentiation_score': 1.5,
                'timing_score': 1.5,
                'score': 8.0
            },
            {
                'name': 'Intégrations locales',
                'impact': 6.5,
                'ease': 5,
                'impact_score': 2.2,
                'ease_score': 1.7,
                'differentiation_score': 1.8,
                'timing_score': 1.5,
                'score': 7.2
            },
            {
                'name': 'RGPD compliance avancée',
                'impact': 8,
                'ease': 4,
                'impact_score': 2.7,
                'ease_score': 1.3,
                'differentiation_score': 1.8,
                'timing_score': 2,
                'score': 7.8
            },
            {
                'name': 'Pricing transparent',
                'impact': 5,
                'ease': 9,
                'impact_score': 1.7,
                'ease_score': 3,
                'differentiation_score': 1.2,
                'timing_score': 1,
                'score': 6.9
            },
            {
                'name': 'Features IA avancées',
                'impact': 9,
                'ease': 3,
                'impact_score': 3,
                'ease_score': 1,
                'differentiation_score': 2,
                'timing_score': 1.5,
                'score': 7.5
            }
        ]

    # Generate matrices for each format
    formats = [f.strip() for f in args.format.split(',')]

    print(f"\n📊 Génération des matrices d'opportunités...\n")

    for fmt in formats:
        # Generate opportunity matrix
        create_opportunity_matrix(opportunities, output_path, fmt)

        # Generate scoring chart
        create_scoring_chart(opportunities, output_path, fmt)

    # Generate markdown ranking (always)
    create_priority_ranking_md(opportunities, output_path)

    print(f"\n✅ Toutes les matrices d'opportunités ont été générées dans : {output_path}")
    print(f"\n💡 Pour personnaliser, créez un fichier '{args.input}' avec vos données.")


if __name__ == '__main__':
    main()

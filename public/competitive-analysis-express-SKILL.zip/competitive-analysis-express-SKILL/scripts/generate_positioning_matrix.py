#!/usr/bin/env python3
"""
Generate positioning matrices for competitive analysis.

This script creates visual positioning matrices:
- Price vs Value matrix
- Custom 2-axis strategic positioning matrix
- Multi-criteria radar chart

Usage:
    python generate_positioning_matrix.py --output analysis_output --format png,svg
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict, Tuple
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np


def create_price_value_matrix(
    competitors: List[Dict[str, any]],
    output_path: Path,
    format: str = "png"
) -> None:
    """
    Create a Price vs Value positioning matrix.

    Args:
        competitors: List of competitor data with 'name', 'price_score', 'value_score'
        output_path: Directory to save the output file
        format: Image format ('png' or 'svg')
    """
    fig, ax = plt.subplots(figsize=(12, 10))

    # Set up the plot
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_xlabel('Prix (0=Bas, 10=Élevé)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Valeur perçue (0=Basse, 10=Haute)', fontsize=14, fontweight='bold')
    ax.set_title('MATRICE DE POSITIONNEMENT : Prix vs Valeur', fontsize=16, fontweight='bold', pad=20)

    # Add grid
    ax.grid(True, alpha=0.3, linestyle='--')

    # Add quadrant labels
    ax.text(2.5, 8, 'Premium\n(Haute valeur, Prix élevé)',
            ha='center', va='center', fontsize=11, style='italic',
            bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.3))
    ax.text(7.5, 8, 'Luxe\n(Très haute valeur, Prix très élevé)',
            ha='center', va='center', fontsize=11, style='italic',
            bbox=dict(boxstyle='round', facecolor='gold', alpha=0.3))
    ax.text(2.5, 2, 'Low-cost\n(Basse valeur, Prix bas)',
            ha='center', va='center', fontsize=11, style='italic',
            bbox=dict(boxstyle='round', facecolor='lightcoral', alpha=0.3))
    ax.text(7.5, 2, 'Cher sans valeur\n(À éviter)',
            ha='center', va='center', fontsize=11, style='italic',
            bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.3))

    # Plot competitors
    colors = plt.cm.tab10(np.linspace(0, 1, len(competitors)))

    for i, comp in enumerate(competitors):
        is_you = comp.get('is_you', False)
        price = comp.get('price_score', 5)
        value = comp.get('value_score', 5)
        name = comp.get('name', f'Competitor {i+1}')

        if is_you:
            # Highlight "VOUS" with a star
            ax.scatter(price, value, s=500, c='red', marker='*',
                      edgecolors='darkred', linewidths=2, zorder=10,
                      label=f'{name} ⭐ (VOUS)')
            ax.annotate(f'{name}\n⭐ VOUS', (price, value),
                       xytext=(10, 10), textcoords='offset points',
                       fontsize=12, fontweight='bold', color='darkred',
                       bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7),
                       arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0', color='red'))
        else:
            ax.scatter(price, value, s=300, c=[colors[i]], marker='o',
                      edgecolors='black', linewidths=1.5, alpha=0.7,
                      label=name)
            ax.annotate(name, (price, value),
                       xytext=(10, -10), textcoords='offset points',
                       fontsize=10,
                       bbox=dict(boxstyle='round,pad=0.3', facecolor=colors[i], alpha=0.5),
                       arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0.2'))

    # Add legend
    ax.legend(loc='upper left', fontsize=10, framealpha=0.9)

    # Add reference lines
    ax.axhline(y=5, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    ax.axvline(x=5, color='gray', linestyle=':', linewidth=1, alpha=0.5)

    plt.tight_layout()

    # Save the figure
    output_file = output_path / f'matrix_price_value.{format}'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"✅ Matrice Prix vs Valeur générée : {output_file}")
    plt.close()


def create_custom_axes_matrix(
    competitors: List[Dict[str, any]],
    axis_x: str,
    axis_y: str,
    output_path: Path,
    format: str = "png"
) -> None:
    """
    Create a custom 2-axis positioning matrix.

    Args:
        competitors: List of competitor data with 'name', 'x_score', 'y_score'
        axis_x: Label for X axis
        axis_y: Label for Y axis
        output_path: Directory to save the output file
        format: Image format ('png' or 'svg')
    """
    fig, ax = plt.subplots(figsize=(12, 10))

    # Set up the plot
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_xlabel(f'{axis_x} (0=Bas, 10=Élevé)', fontsize=14, fontweight='bold')
    ax.set_ylabel(f'{axis_y} (0=Bas, 10=Élevé)', fontsize=14, fontweight='bold')
    ax.set_title(f'MATRICE DE POSITIONNEMENT STRATÉGIQUE\n{axis_y} vs {axis_x}',
                fontsize=16, fontweight='bold', pad=20)

    # Add grid
    ax.grid(True, alpha=0.3, linestyle='--')

    # Plot competitors
    colors = plt.cm.tab10(np.linspace(0, 1, len(competitors)))

    for i, comp in enumerate(competitors):
        is_you = comp.get('is_you', False)
        x_val = comp.get('x_score', 5)
        y_val = comp.get('y_score', 5)
        name = comp.get('name', f'Competitor {i+1}')

        if is_you:
            ax.scatter(x_val, y_val, s=500, c='red', marker='*',
                      edgecolors='darkred', linewidths=2, zorder=10,
                      label=f'{name} ⭐ (VOUS)')
            ax.annotate(f'{name}\n⭐ VOUS', (x_val, y_val),
                       xytext=(10, 10), textcoords='offset points',
                       fontsize=12, fontweight='bold', color='darkred',
                       bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7),
                       arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0', color='red'))
        else:
            ax.scatter(x_val, y_val, s=300, c=[colors[i]], marker='o',
                      edgecolors='black', linewidths=1.5, alpha=0.7,
                      label=name)
            ax.annotate(name, (x_val, y_val),
                       xytext=(10, -10), textcoords='offset points',
                       fontsize=10,
                       bbox=dict(boxstyle='round,pad=0.3', facecolor=colors[i], alpha=0.5),
                       arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0.2'))

    # Add legend
    ax.legend(loc='upper left', fontsize=10, framealpha=0.9)

    # Add reference lines
    ax.axhline(y=5, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    ax.axvline(x=5, color='gray', linestyle=':', linewidth=1, alpha=0.5)

    plt.tight_layout()

    # Save the figure
    output_file = output_path / f'matrix_custom_axes.{format}'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"✅ Matrice axes personnalisés générée : {output_file}")
    plt.close()


def create_radar_chart(
    competitors: List[Dict[str, any]],
    criteria: List[str],
    output_path: Path,
    format: str = "png"
) -> None:
    """
    Create a radar chart for multi-criteria comparison.

    Args:
        competitors: List of competitor data with 'name' and scores for each criterion
        criteria: List of criteria names
        output_path: Directory to save the output file
        format: Image format ('png' or 'svg')
    """
    # Number of criteria
    num_vars = len(criteria)

    # Compute angle for each axis
    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()

    # The plot is circular, so we need to "close the loop"
    angles += angles[:1]

    # Initialize the plot
    fig, ax = plt.subplots(figsize=(12, 12), subplot_kw=dict(projection='polar'))

    # Plot each competitor
    colors = plt.cm.tab10(np.linspace(0, 1, len(competitors)))

    for i, comp in enumerate(competitors):
        is_you = comp.get('is_you', False)
        name = comp.get('name', f'Competitor {i+1}')

        # Extract scores for each criterion
        values = [comp.get('scores', {}).get(crit, 5) for crit in criteria]
        values += values[:1]  # Close the loop

        # Plot
        if is_you:
            ax.plot(angles, values, 'o-', linewidth=3, label=f'{name} ⭐ (VOUS)',
                   color='red', markersize=8)
            ax.fill(angles, values, alpha=0.25, color='red')
        else:
            ax.plot(angles, values, 'o-', linewidth=2, label=name,
                   color=colors[i], alpha=0.7, markersize=6)
            ax.fill(angles, values, alpha=0.15, color=colors[i])

    # Fix axis to go in the right order and start at 12 o'clock
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    # Set labels
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(criteria, fontsize=11)

    # Set y-axis limits
    ax.set_ylim(0, 10)
    ax.set_yticks([2, 4, 6, 8, 10])
    ax.set_yticklabels(['2', '4', '6', '8', '10'], fontsize=9, color='gray')

    # Add title
    ax.set_title('GRAPHIQUE RADAR : Positionnement Multi-Critères',
                fontsize=16, fontweight='bold', pad=30)

    # Add legend
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=10, framealpha=0.9)

    # Add grid
    ax.grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()

    # Save the figure
    output_file = output_path / f'radar_positioning.{format}'
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"✅ Graphique radar généré : {output_file}")
    plt.close()


def main():
    """Main function to generate positioning matrices."""
    parser = argparse.ArgumentParser(
        description='Generate positioning matrices for competitive analysis'
    )
    parser.add_argument('--input', type=str, default='competitors_data.json',
                       help='Input JSON file with competitor data')
    parser.add_argument('--output', type=str, default='output',
                       help='Output directory for generated files')
    parser.add_argument('--format', type=str, default='png',
                       help='Image format (png or svg), comma-separated for multiple')
    parser.add_argument('--axis-x', type=str, default='Simplicité',
                       help='Label for X axis (custom matrix)')
    parser.add_argument('--axis-y', type=str, default='Puissance',
                       help='Label for Y axis (custom matrix)')

    args = parser.parse_args()

    # Create output directory
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    # Load competitor data
    input_file = Path(args.input)
    if input_file.exists():
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            competitors = data.get('competitors', [])
            criteria = data.get('criteria', [])
    else:
        # Example data if no input file
        print("⚠️  Fichier d'entrée non trouvé. Utilisation de données d'exemple.")
        competitors = [
            {
                'name': 'VOUS',
                'is_you': True,
                'price_score': 6,
                'value_score': 8,
                'x_score': 8,
                'y_score': 7,
                'scores': {
                    'Prix': 6,
                    'Fonctionnalités': 8,
                    'Support': 9,
                    'Facilité': 8,
                    'Innovation': 7,
                    'Fiabilité': 8
                }
            },
            {
                'name': 'Concurrent A',
                'price_score': 8,
                'value_score': 7,
                'x_score': 5,
                'y_score': 9,
                'scores': {
                    'Prix': 3,
                    'Fonctionnalités': 9,
                    'Support': 6,
                    'Facilité': 5,
                    'Innovation': 8,
                    'Fiabilité': 9
                }
            },
            {
                'name': 'Concurrent B',
                'price_score': 4,
                'value_score': 5,
                'x_score': 7,
                'y_score': 6,
                'scores': {
                    'Prix': 8,
                    'Fonctionnalités': 6,
                    'Support': 5,
                    'Facilité': 8,
                    'Innovation': 5,
                    'Fiabilité': 7
                }
            },
            {
                'name': 'Concurrent C',
                'price_score': 3,
                'value_score': 3,
                'x_score': 9,
                'y_score': 4,
                'scores': {
                    'Prix': 9,
                    'Fonctionnalités': 4,
                    'Support': 3,
                    'Facilité': 9,
                    'Innovation': 3,
                    'Fiabilité': 5
                }
            }
        ]
        criteria = ['Prix', 'Fonctionnalités', 'Support', 'Facilité', 'Innovation', 'Fiabilité']

    # Generate matrices for each format
    formats = [f.strip() for f in args.format.split(',')]

    for fmt in formats:
        print(f"\n📊 Génération des matrices au format {fmt.upper()}...")

        # Generate Price vs Value matrix
        create_price_value_matrix(competitors, output_path, fmt)

        # Generate custom axes matrix
        create_custom_axes_matrix(competitors, args.axis_x, args.axis_y, output_path, fmt)

        # Generate radar chart
        create_radar_chart(competitors, criteria, output_path, fmt)

    print(f"\n✅ Toutes les matrices ont été générées dans : {output_path}")
    print(f"\n💡 Pour personnaliser, créez un fichier '{args.input}' avec vos données.")


if __name__ == '__main__':
    main()

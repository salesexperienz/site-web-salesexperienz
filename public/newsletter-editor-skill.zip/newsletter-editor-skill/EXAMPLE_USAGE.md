# Exemples d'utilisation

## Exemple 1 — Newsletter complète

**Commande :**
```
/newsletter Édition #05 · Prospection LinkedIn

Titre : Tu prospectes. Personne ne répond.
Sous-titre : Ce que j'ai changé pour passer de 2 % à 18 % de taux de réponse.

Introduction :
Tu envoies des messages. Tu attends. Rien.
Pas parce que ton offre est mauvaise. Parce que le message arrive au mauvais endroit, au mauvais moment, avec le mauvais angle.
Dans cette édition, je te partage ce qui a tout changé pour moi.

Section 1 — Le vrai problème n'est pas ton message :
La plupart cherchent le script parfait. Mais le problème est en amont.
Google ne te voit pas parce que ta fiche est vide, pas parce que tu n'as pas le bon mot-clé.

...
```

**Résultat généré :**
```json
{
  "edition": "Édition #05 · Prospection LinkedIn",
  "titre": "Tu prospectes.\nPersonne ne répond.",
  "soustitre": "Ce que j'ai changé pour passer de 2 % à 18 % de taux de réponse.",
  "intro": "Tu envoies des messages. Tu attends. Rien.\n\nPas parce que ton offre est mauvaise. Parce que le message arrive au mauvais endroit, au mauvais moment, avec le mauvais angle.\n\nDans cette édition, je te partage ce qui a tout changé pour moi.",
  "s1titre": "Le vrai problème n'est pas ton message",
  "s1corps": "La plupart cherchent le script parfait. Mais le problème est en amont.\n\nGoogle ne te voit pas parce que ta fiche est vide, pas parce que tu n'as pas le bon mot-clé."
}
```

## Exemple 2 — Newsletter partielle (2 sections seulement)

Le skill s'adapte : si ta newsletter n'a que 2 sections, le JSON ne contiendra que `s1` et `s2`. Pas de champs vides forcés.

## Règles de formatage rappel

| Situation | Format |
|---|---|
| Saut de paragraphe | `\n\n` |
| Item de liste (sommaire, s3items) | `\n` entre chaque ligne |
| Item section 2 (titre + description) | `"Titre\nDescription"` |
| Guillemet dans le texte | `\"` |
| Titre sur 2 lignes | `"Ligne 1\nLigne 2"` |

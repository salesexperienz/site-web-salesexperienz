# 🚀 QUICKSTART - Competitive Analysis Express

Guide de démarrage rapide pour utiliser le skill immédiatement.

## Installation rapide (2 minutes)

### 1. Installer les dépendances Python

```bash
cd competitive-analysis-express-SKILL
pip install -r requirements.txt
```

### 2. Tester avec l'exemple inclus

```bash
# Générer tous les visuels d'exemple en une commande
./scripts/generate_all_visuals.sh
```

Résultat : Le dossier `analysis_output/` contiendra tous les visuels générés avec des données d'exemple.

---

## Utilisation avec Claude (3 minutes)

### Option 1 : Analyse guidée complète

Invoquez simplement le skill :

```
/competitive-analysis-express
```

ou

```
Fais-moi une analyse concurrentielle express
```

Claude vous posera 4 questions et générera l'analyse complète.

### Option 2 : Analyse directe

Fournissez directement les informations :

```
Analyse concurrentielle pour :
- Offre : SaaS de gestion de projet pour PME françaises
- Secteur : SaaS B2B
- Concurrents : Monday, Asana, Trello, Notion
```

---

## Générer vos propres visuels (5 minutes)

### Étape 1 : Créez votre fichier de données

Copiez un template depuis `assets/` :

```bash
cp assets/competitors_data_template.json mes_donnees.json
```

### Étape 2 : Remplissez vos données

Éditez `mes_donnees.json` avec vos informations réelles.

### Étape 3 : Générez tous les visuels

```bash
./scripts/generate_all_visuals.sh mes_donnees.json mon_analyse
```

Tous vos visuels seront dans `mon_analyse/`.

---

## Scripts individuels

### Matrices de positionnement

```bash
python3 scripts/generate_positioning_matrix.py \
  --input mes_donnees.json \
  --output mon_analyse \
  --format png
```

### Tableaux comparatifs Excel

```bash
python3 scripts/generate_comparison_table.py \
  --input mes_donnees.json \
  --output mon_analyse \
  --format excel
```

### Matrices d'opportunités

```bash
python3 scripts/generate_opportunity_matrix.py \
  --input mes_opportunites.json \
  --output mon_analyse \
  --format png
```

### Battle cards PDF

```bash
python3 scripts/generate_battle_cards.py \
  --input mes_battlecards.json \
  --output mon_analyse \
  --format pdf \
  --combined
```

---

## Exemples de cas d'usage

### Cas 1 : Préparer un pitch investisseur

1. Lancez l'analyse avec Claude
2. Générez les matrices visuelles (PNG)
3. Intégrez dans votre deck :
   - Slide "Positionnement marché" : `matrix_price_value.png`
   - Slide "Opportunités" : `opportunity_matrix.png`
   - Slide "Avantage concurrentiel" : `radar_positioning.png`

### Cas 2 : Former l'équipe commerciale

1. Générez les battle cards PDF
2. Imprimez `battlecards_all.pdf`
3. Distribuez une battle card par commercial
4. Organisez un role-play avec les objections typiques

### Cas 3 : Analyse stratégique trimestrielle

1. Créez votre fichier JSON avec données à jour
2. Générez tous les visuels : `./scripts/generate_all_visuals.sh`
3. Ouvrez `comparison_analysis.xlsx` pour analyse quantitative
4. Partagez le fichier Excel avec l'équipe direction

---

## Astuces pro

### 🎨 Personnaliser les couleurs

Éditez les scripts Python et changez les valeurs de couleurs :

```python
# Dans generate_positioning_matrix.py, ligne ~XX
facecolor='lightblue'  # Changez en '#FF6B6B', 'lightgreen', etc.
```

### 📊 Ajouter vos propres critères

Dans votre JSON, ajoutez vos critères spécifiques :

```json
{
  "criteria": [
    "Prix",
    "Support",
    "Mon critère custom 1",
    "Mon critère custom 2"
  ]
}
```

### 🔄 Automatiser avec un cron

Créez un script qui met à jour automatiquement votre analyse :

```bash
#!/bin/bash
# update_analysis.sh
cd /path/to/skill
./scripts/generate_all_visuals.sh data/competitors.json reports/$(date +%Y-%m-%d)
```

---

## FAQ rapide

**Q: Les scripts ne fonctionnent pas**
A: Vérifiez l'installation : `pip install matplotlib numpy pandas openpyxl`

**Q: Puis-je utiliser sans les scripts Python ?**
A: Oui ! Claude génère tous les tableaux en Markdown. Les scripts sont un bonus pour les visuels.

**Q: Combien de concurrents analyser ?**
A: 3 à 5 concurrents principaux pour une analyse efficace.

**Q: À quelle fréquence mettre à jour ?**
A: Recommandation : tous les trimestres, ou avant événements importants (levée, lancement).

---

## Support

- Documentation complète : `README.md`
- Documentation scripts : `references/scripts_documentation.md`
- Templates JSON : `assets/*.json`

---

**Temps total d'installation et premier usage : < 10 minutes**

Bon travail ! 🎉

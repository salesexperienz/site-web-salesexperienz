---
name: newsletter
description: Formate le contenu d'une newsletter rédigée en JSON prêt à importer dans l'éditeur de newsletter Sales Expérienz. Utilise ce skill quand l'utilisateur a rédigé une newsletter et veut l'importer dans son éditeur, ou quand il demande à générer le JSON de sa newsletter.
---

# Newsletter Editor — Formateur JSON

## Rôle

Ce skill prend le contenu d'une newsletter rédigée (texte libre) et le formate en JSON valide, prêt à coller dans le bouton **"Importer depuis Claude"** de l'éditeur de newsletter.

## Principe de flexibilité

N'inclus que les champs qui correspondent à du contenu réellement présent dans le texte fourni. Si une section n'existe pas, omets la clé ou mets `"À compléter"`.

## Correspondance sections → champs JSON

| Contenu rédigé | Clé JSON | Format |
|---|---|---|
| Numéro / thème | `edition` | `"Édition #05 · Sujet"` |
| Catégorie | `categorie` | Court, ex: `"SEO & Visibilité"` |
| Titre principal | `titre` | Utilise `\n` pour les sauts de ligne |
| Sous-titre / accroche | `soustitre` | Phrase italique |
| Introduction (après "Salut,") | `intro` | Paragraphes séparés par `\n\n` |
| Sommaire | `sommaire` | Chaque point sur une ligne, commence par `→` |
| Section 1 — titre | `s1titre` | |
| Section 1 — corps | `s1corps` | Paragraphes séparés par `\n\n` |
| Section 1 — citation / résumé | `s1resume` | Entre guillemets `\"...\"` |
| Section 2 — titre | `s2titre` | |
| Section 2 — item 1 | `s2item1` | `"Titre\nDescription"` |
| Section 2 — item 2 | `s2item2` | idem |
| Section 2 — item 3 | `s2item3` | idem |
| Section 3 — titre | `s3titre` | |
| Section 3 — points clés | `s3items` | `"Titre en gras — description"`, un par ligne (`\n`) |
| Section 4 — titre | `s4titre` | |
| Section 4 — corps | `s4corps` | Paragraphes séparés par `\n\n` |
| Chiffre clé | `chiffre` | Ex: `"46 %"` |
| Phrase du chiffre | `chiffreTexte` | |
| Titre bloc actions | `actionsH` | |
| Action 1 | `action1` | |
| Action 2 | `action2` | |
| Action 3 | `action3` | |
| Titre CTA / ressource | `ctotire` | |
| Conclusion | `conclu` | Paragraphes séparés par `\n\n` |
| Post-scriptum | `ps` | Une seule phrase |

## Champs à ne jamais inclure

`img1`, `img1After`, `img2`, `img2After`, `footerTitre`, `rdv`, `rdvTexte`, `rdvDesc`, `guide`, `guideTexte`, `guideDesc`, `siteUrl`, `siteTexte`, `siteDesc`, `youtube`, `linkedin`, `footerNom`

Ces champs sont gérés séparément dans l'éditeur et ne doivent pas être générés.

## Format de sortie

Réponds UNIQUEMENT avec le JSON brut :
- Sans bloc de code markdown
- Sans texte avant ou après
- Guillemets internes échappés avec `\"`
- `\n\n` entre les paragraphes dans les champs multi-lignes
- `\n` simple entre les items de liste (`sommaire`, `s3items`, `s2item1`…)

## Exemple de sortie attendue

```
{
  "edition": "Édition #05 · Prospection LinkedIn",
  "categorie": "Prospection & Vente",
  "titre": "Tu prospectes.\nPersonne ne répond.",
  "soustitre": "Ce que j'ai changé pour passer de 2 % à 18 % de taux de réponse — sans script.",
  "intro": "Tu envoies des messages. Tu attends. Rien.\n\nPas parce que ton offre est mauvaise. Parce que le message arrive au mauvais endroit, au mauvais moment, avec le mauvais angle.",
  "s1titre": "Le vrai problème n'est pas ton message",
  "s1corps": "La plupart des gens cherchent le script parfait. Mais le problème est en amont.",
  "conclu": "La prospection qui fonctionne n'est pas celle qui insiste.\n\nC'est celle qui arrive au bon moment, avec la bonne accroche.",
  "ps": "PS : si une seule chose devait rester — c'est ça."
}
```

Formate maintenant le contenu suivant :

$ARGUMENTS

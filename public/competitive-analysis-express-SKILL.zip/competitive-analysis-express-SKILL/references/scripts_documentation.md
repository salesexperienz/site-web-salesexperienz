# DOCUMENTATION DES SCRIPTS

Cette documentation détaille l'utilisation de tous les scripts Python disponibles dans le skill Competitive Analysis Express.

## Vue d'ensemble

Le skill fournit 4 scripts Python principaux pour automatiser la génération de visuels et d'exports :

1. **generate_positioning_matrix.py** - Matrices de positionnement
2. **generate_comparison_table.py** - Tableaux comparatifs multi-formats
3. **generate_opportunity_matrix.py** - Matrices d'opportunités
4. **generate_battle_cards.py** - Battle cards visuelles

## Prérequis

### Installation des dépendances

```bash
pip install matplotlib numpy pandas openpyxl
```

### Structure de données attendue

Tous les scripts peuvent fonctionner avec ou sans fichier d'entrée JSON. Sans fichier, ils utilisent des données d'exemple pour démonstration.

---

## 1. generate_positioning_matrix.py

### Description

Génère des matrices de positionnement visuelles pour comparer votre offre avec vos concurrents.

### Sorties produites

- **matrix_price_value.[format]** : Matrice Prix vs Valeur perçue
- **matrix_custom_axes.[format]** : Matrice sur axes personnalisés
- **radar_positioning.[format]** : Graphique radar multi-critères

### Utilisation basique

```bash
# Avec données d'exemple
python scripts/generate_positioning_matrix.py --output analysis_output --format png

# Avec vos données
python scripts/generate_positioning_matrix.py \
  --input mes_donnees.json \
  --output analysis_output \
  --format png,svg
```

### Paramètres

| Paramètre | Description | Défaut | Requis |
|-----------|-------------|--------|--------|
| `--input` | Fichier JSON avec données concurrents | `competitors_data.json` | Non |
| `--output` | Répertoire de sortie | `output` | Non |
| `--format` | Formats d'image (png, svg) | `png` | Non |
| `--axis-x` | Label axe X (matrice custom) | `Simplicité` | Non |
| `--axis-y` | Label axe Y (matrice custom) | `Puissance` | Non |

### Format du fichier JSON d'entrée

```json
{
  "competitors": [
    {
      "name": "VOUS",
      "is_you": true,
      "price_score": 6,
      "value_score": 8,
      "x_score": 8,
      "y_score": 7,
      "scores": {
        "Prix": 6,
        "Fonctionnalités": 8,
        "Support": 9,
        "Facilité": 8,
        "Innovation": 7,
        "Fiabilité": 8
      }
    },
    {
      "name": "Concurrent A",
      "price_score": 8,
      "value_score": 7,
      "x_score": 5,
      "y_score": 9,
      "scores": {
        "Prix": 3,
        "Fonctionnalités": 9,
        "Support": 6,
        "Facilité": 5,
        "Innovation": 8,
        "Fiabilité": 9
      }
    }
  ],
  "criteria": ["Prix", "Fonctionnalités", "Support", "Facilité", "Innovation", "Fiabilité"]
}
```

### Échelle de scoring

- **price_score** : 0 (bas prix) à 10 (prix élevé)
- **value_score** : 0 (basse valeur) à 10 (haute valeur)
- **x_score / y_score** : 0 à 10 sur axes personnalisés
- **scores[critère]** : 0 à 10 pour chaque critère

---

## 2. generate_comparison_table.py

### Description

Crée des tableaux comparatifs dans plusieurs formats pour faciliter l'analyse et le partage.

### Sorties produites

- **comparison_table.md** : Tableau formaté en Markdown
- **comparison_data.csv** : Export CSV pour import Excel/Google Sheets
- **comparison_analysis.xlsx** : Fichier Excel multi-onglets avec graphiques

### Utilisation basique

```bash
# Tous les formats
python scripts/generate_comparison_table.py \
  --output analysis_output \
  --format markdown,csv,excel

# Uniquement Excel
python scripts/generate_comparison_table.py \
  --output analysis_output \
  --format excel
```

### Paramètres

| Paramètre | Description | Défaut | Requis |
|-----------|-------------|--------|--------|
| `--input` | Fichier JSON avec données concurrents | `competitors_data.json` | Non |
| `--output` | Répertoire de sortie | `output` | Non |
| `--format` | Formats de sortie (markdown, csv, excel) | `markdown,csv,excel` | Non |

### Format du fichier JSON d'entrée

```json
{
  "competitors": [
    {
      "name": "VOUS",
      "is_you": true,
      "criteria": {
        "Prix": "12€/user",
        "Modèle économique": "SaaS mensuel",
        "Cible principale": "PME 5-50 employés",
        "Support client": "⭐⭐⭐⭐⭐ FR"
      },
      "scores": {
        "Prix": 6,
        "Fonctionnalités": 8
      },
      "strengths": [
        "Support client français réactif",
        "Interface intuitive"
      ],
      "weaknesses": [
        "Moins de features que les leaders",
        "Marque moins connue"
      ]
    }
  ],
  "criteria": ["Prix", "Modèle économique", "Cible principale", "Support client"]
}
```

### Onglets Excel générés

1. **Comparaison** : Tableau complet de tous les critères
2. **Scoring** : Notes numériques par critère
3. **Forces-Faiblesses** : Liste détaillée des forces et faiblesses
4. **Synthèse** : Statistiques récapitulatives et moyennes

---

## 3. generate_opportunity_matrix.py

### Description

Visualise les opportunités identifiées selon leur impact et facilité d'exécution.

### Sorties produites

- **opportunity_matrix.[format]** : Matrice 2x2 Impact vs Facilité
- **opportunity_scores.[format]** : Graphique de scoring détaillé
- **priority_ranking.md** : Classement des opportunités par priorité

### Utilisation basique

```bash
# Génération standard
python scripts/generate_opportunity_matrix.py \
  --output analysis_output \
  --format png

# Multi-formats
python scripts/generate_opportunity_matrix.py \
  --output analysis_output \
  --format png,svg
```

### Paramètres

| Paramètre | Description | Défaut | Requis |
|-----------|-------------|--------|--------|
| `--input` | Fichier JSON avec opportunités | `opportunities_data.json` | Non |
| `--output` | Répertoire de sortie | `output` | Non |
| `--format` | Formats d'image (png, svg) | `png` | Non |

### Format du fichier JSON d'entrée

```json
{
  "opportunities": [
    {
      "name": "Support FR premium",
      "impact": 8.5,
      "ease": 7,
      "impact_score": 2.8,
      "ease_score": 2.3,
      "differentiation_score": 2,
      "timing_score": 1.8,
      "score": 8.9
    },
    {
      "name": "Onboarding personnalisé",
      "impact": 7,
      "ease": 8,
      "impact_score": 2.3,
      "ease_score": 2.7,
      "differentiation_score": 1.5,
      "timing_score": 1.5,
      "score": 8.0
    }
  ]
}
```

### Calcul du score

**Score total (/10) = impact_score + ease_score + differentiation_score + timing_score**

Où :
- **impact_score** : 0-3 points (impact marché)
- **ease_score** : 0-3 points (facilité exécution)
- **differentiation_score** : 0-2 points (différenciation créée)
- **timing_score** : 0-2 points (momentum / timing)

### Niveaux de priorité

- **🥇 PRIORITÉ 1** (8-10/10) : Quick wins à implémenter immédiatement
- **🥈 PRIORITÉ 2** (6-8/10) : Opportunités nécessitant investissement
- **🥉 PRIORITÉ 3** (4-6/10) : À considérer selon ressources
- **❌ Ignorer** (<4/10) : Faible ROI, pas prioritaire

---

## 4. generate_battle_cards.py

### Description

Crée des battle cards visuelles professionnelles pour chaque concurrent.

### Sorties produites

- **battlecard_[concurrent].pdf** : Une battle card PDF par concurrent
- **battlecard_[concurrent].png** : Une battle card PNG par concurrent
- **battlecards_all.pdf** : PDF combiné avec toutes les battle cards

### Utilisation basique

```bash
# Génération PDF et PNG
python scripts/generate_battle_cards.py \
  --output analysis_output \
  --format pdf,png

# Uniquement PDF avec fichier combiné
python scripts/generate_battle_cards.py \
  --output analysis_output \
  --format pdf \
  --combined
```

### Paramètres

| Paramètre | Description | Défaut | Requis |
|-----------|-------------|--------|--------|
| `--input` | Fichier JSON avec données battle cards | `battlecards_data.json` | Non |
| `--output` | Répertoire de sortie | `output` | Non |
| `--format` | Formats de sortie (pdf, png) | `pdf,png` | Non |
| `--combined` | Générer PDF combiné | `False` | Non |

### Format du fichier JSON d'entrée

```json
{
  "competitors": [
    {
      "name": "Concurrent A",
      "size": "500+ employés, €100M+ CA",
      "founded": "2010, Silicon Valley",
      "target": "Grandes entreprises",
      "pricing": "24-50€/user/mois",
      "strengths": [
        "Fonctionnalités très complètes",
        "Fiabilité éprouvée",
        "Grande notoriété"
      ],
      "weaknesses": [
        "Prix élevé",
        "Complexité importante",
        "Support limité en français"
      ],
      "objections": [
        {
          "objection": "Concurrent A a plus de fonctionnalités",
          "response": "C'est vrai. Maintenant, 70% de leurs clients n'utilisent que 30% des fonctionnalités..."
        }
      ],
      "when_recommend_them": "Concurrent A est excellent si vous êtes une grande entreprise...",
      "when_recommend_us": [
        "Vous êtes une PME de 5-50 employés",
        "Vous cherchez une solution opérationnelle rapidement"
      ]
    }
  ]
}
```

### Sections incluses dans chaque battle card

1. **À SAVOIR** : Informations clés sur le concurrent
2. **LEURS FORCES** : Ce qu'ils font bien (à reconnaître)
3. **LEURS FAIBLESSES** : Points d'attaque potentiels
4. **OBJECTIONS TYPIQUES & RÉPONSES** : Argumentaires prêts à l'emploi
5. **QUAND LES RECOMMANDER** : Fair play et crédibilité
6. **QUAND NOUS RECOMMANDER** : Critères de différenciation

---

## Workflow complet d'utilisation

### Étape 1 : Créer le fichier de données

Créez un fichier JSON `my_competitors.json` avec vos données :

```json
{
  "competitors": [...],
  "criteria": [...],
  "opportunities": [...]
}
```

### Étape 2 : Générer tous les visuels

```bash
# Matrices de positionnement
python scripts/generate_positioning_matrix.py \
  --input my_competitors.json \
  --output analysis_output \
  --format png,svg

# Tableaux comparatifs
python scripts/generate_comparison_table.py \
  --input my_competitors.json \
  --output analysis_output \
  --format markdown,csv,excel

# Matrices d'opportunités
python scripts/generate_opportunity_matrix.py \
  --input my_opportunities.json \
  --output analysis_output \
  --format png,svg

# Battle cards
python scripts/generate_battle_cards.py \
  --input my_battlecards.json \
  --output analysis_output \
  --format pdf,png \
  --combined
```

### Étape 3 : Intégrer dans votre analyse

Tous les fichiers générés se trouvent dans `analysis_output/` :

- **Markdown** : À intégrer dans votre rapport d'analyse
- **Excel/CSV** : Pour analyse quantitative et partage
- **PNG/SVG** : Pour présentations et documents
- **PDF** : Pour impression et distribution à l'équipe commerciale

---

## Dépannage

### Erreur : Module not found

```bash
# Installer les dépendances manquantes
pip install matplotlib numpy pandas openpyxl
```

### Les caractères spéciaux ne s'affichent pas

Assurez-vous que votre fichier JSON est encodé en UTF-8.

### Les graphiques sont coupés

Augmentez la résolution avec le paramètre `dpi` dans le code (par défaut 300).

### Le texte déborde des battle cards

Réduisez la longueur des textes dans votre JSON ou ajustez le paramètre `width` dans `wrap_text()`.

---

## Personnalisation avancée

### Modifier les couleurs

Dans chaque script, vous pouvez modifier les couleurs en changeant les valeurs RGB/hex :

```python
# Exemple dans generate_positioning_matrix.py
facecolor='lightblue'  # Changer en 'lightgreen', '#FF6B6B', etc.
```

### Ajuster la taille des graphiques

```python
fig = plt.figure(figsize=(12, 10))  # Largeur, Hauteur en pouces
```

### Changer les polices

```python
plt.rcParams['font.family'] = 'Arial'  # ou 'Helvetica', 'Times New Roman'
```

---

## Support

Pour toute question ou problème :
1. Vérifiez que les dépendances sont installées
2. Testez avec les données d'exemple (sans fichier --input)
3. Vérifiez le format de votre JSON avec un validateur en ligne
4. Consultez les messages d'erreur Python pour identifier le problème

---

**Dernière mise à jour** : 2025-01-25

---
name: competitive-analysis-express
description: Analyse concurrentielle rapide avec recherche web automatique pour comparer offres, identifier gaps de marché et créer matrices de positionnement différenciantes. S'intègre avec ocean-bleu-skills si disponible.
---

# SKILL: COMPETITIVE ANALYSIS EXPRESS

## Vue d'ensemble
Réaliser une analyse concurrentielle rapide et complète (15-20 min) avec recherche web automatique. Identifier les opportunités de marché non-exploitées, créer des matrices de positionnement stratégiques et générer des arguments différenciants actionnables. Peut s'intégrer avec le skill ocean-bleu-skills si disponible pour une stratégie complète.

## Quand utiliser ce skill
- Lancer une nouvelle offre sur un marché existant
- Repositionner son offre face à la concurrence
- Identifier des opportunités de différenciation
- Préparer une stratégie commerciale ou marketing
- Créer des battle cards pour l'équipe de vente
- Analyser l'évolution du marché
- Préparer une levée de fonds ou un pitch investisseur
- Former son équipe sur le positionnement concurrentiel

## Connexion avec le skill OCEAN-BLEU-SKILLS
Si le skill ocean-bleu-skills est disponible, proposer automatiquement de l'utiliser pour transformer les gaps identifiés en stratégie Océan Bleu complète (matrice ERAC, canevas stratégique). Sinon, le skill fonctionne de manière 100% autonome.

---

## MÉTHODOLOGIE D'ANALYSE

### Approche en 4 phases

**PHASE 1 : DÉCOUVERTE & COLLECTE** (5 min)
- Comprendre l'offre et le secteur de l'utilisateur
- Identifier 3-5 concurrents principaux
- Recherche web automatique sur chaque concurrent

**PHASE 2 : ANALYSE COMPARATIVE** (5-7 min)
- Tableau comparatif multi-critères
- Identification forces/faiblesses
- Positionnement relatif

**PHASE 3 : IDENTIFICATION OPPORTUNITÉS** (5 min)
- Gaps de marché (angles morts)
- Segments sous-servis
- Besoins non-satisfaits
- Tendances émergentes

**PHASE 4 : STRATÉGIE & ACTIONNABILITÉ** (3-5 min)
- Arguments différenciants
- Battle cards par concurrent
- Quick wins et plan d'action
- (Optionnel) Intégration stratégie Océan Bleu

---

## WORKFLOW DE GÉNÉRATION

### Étape 1 : Questions initiales

Poser systématiquement ces questions :

**Q1 : Quelle est votre offre ?**
```
"Décrivez en 2-3 phrases ce que vous proposez :
- Produit ou service ?
- Problème résolu ?
- Cible principale ?"
```

**Q2 : Quel est votre secteur d'activité ?**
```
"Dans quel secteur opérez-vous ?
Ex: SaaS B2B, E-commerce, Conseil, Services B2C, Industrie, etc."
```

**Q3 : Qui sont vos 3-5 principaux concurrents ?**
```
"Listez vos concurrents directs (3 minimum, 5 maximum) :
- Nom 1
- Nom 2
- Nom 3
- Nom 4 (optionnel)
- Nom 5 (optionnel)

Si vous ne les connaissez pas tous, donnez-moi au moins 2 noms
et je chercherai les autres."
```

**Q4 : Avez-vous des informations spécifiques ?**
```
"Y a-t-il des éléments que vous connaissez déjà sur vos concurrents ?
(Prix, positionnement, forces/faiblesses...)
Cela accélérera l'analyse, mais c'est optionnel."
```

---

### Étape 2 : Définition des critères d'analyse adaptés au secteur

Adapter automatiquement les critères selon le secteur.

#### Critères universels (tous secteurs)

1. **Prix / Modèle économique**
2. **Cible principale**
3. **Positionnement / Message clé**
4. **Points forts principaux**
5. **Points faibles / Limites**

#### Critères spécifiques par type de secteur

**SaaS / Tech B2B :**
- Intégrations disponibles
- Support client (langues, horaires, canaux)
- Onboarding / Facilité d'adoption
- Sécurité / Conformité
- API / Personnalisation

**E-commerce / Retail :**
- Gamme de produits / Catalogue
- Délais et frais de livraison
- Politique de retour
- Service client / SAV
- Expérience utilisateur site

**Services / Conseil :**
- Expertise / Spécialisation
- Références clients / Témoignages
- Processus / Méthodologie
- Garanties offertes
- Délais d'intervention

**B2C / Grand public :**
- Notoriété / Visibilité
- Canaux de distribution
- Expérience client
- Communauté / Engagement
- Programme fidélité

**Industrie / Manufacturing :**
- Capacité de production
- Qualité / Certifications
- Délais de fabrication
- Personnalisation / MOQ
- Logistique / Distribution

**Santé / Médical :**
- Certifications / Agréments
- Protocoles / Normes
- Équipements / Technologies
- Expertise médicale
- Réseau de partenaires

**Finance / Assurance :**
- Taux / Tarifs
- Conditions / Eligibilité
- Garanties / Couvertures
- Services associés
- Réputation / Solidité

---

### Étape 3 : Recherche web automatique

Pour chaque concurrent, utiliser web_search et web_fetch pour collecter des informations.

#### Sources d'information prioritaires

1. **Site officiel**
   - Page d'accueil (positionnement, message clé)
   - Page tarifs / pricing
   - Page "À propos" (histoire, mission, valeurs)
   - Page produits/services (features, offres)
   - Témoignages clients / Case studies

2. **Avis et comparateurs**
   - G2, Capterra, Trustpilot (SaaS/Tech)
   - Avis Google, TripAdvisor (Services locaux)
   - Forums spécialisés du secteur
   - Reddit, Quora (avis authentiques)

3. **Actualités et presse**
   - Articles récents (levées, lancements, pivots)
   - Communiqués de presse
   - Interviews dirigeants
   - Analyses sectorielles

4. **Réseaux sociaux**
   - LinkedIn (taille entreprise, recrutement)
   - Posts/publications récentes
   - Engagement communauté

5. **Données publiques**
   - Chiffres clés (CA, croissance, effectifs)
   - Parts de marché estimées
   - Positionnement tarifaire

#### Stratégie de recherche par concurrent

**Recherche 1 : Site officiel + positionnement**
```
web_search: "[Nom concurrent] pricing features [secteur]"
web_fetch: Site officiel identifié
```

**Recherche 2 : Avis clients**
```
web_search: "[Nom concurrent] avis clients avantages inconvénients"
ou
web_search: "[Nom concurrent] review pros cons"
```

**Recherche 3 : Positionnement concurrentiel**
```
web_search: "[Nom concurrent] vs alternatives comparison [secteur]"
```

**Recherche 4 : Actualité récente** (optionnel si pertinent)
```
web_search: "[Nom concurrent] news 2025"
```

---

## PHASE 2 : ANALYSE COMPARATIVE

### Tableau comparatif structuré

#### Appeler le script de génération de tableaux

Utiliser le script `scripts/generate_comparison_table.py` pour créer :
- Tableau comparatif en Markdown
- Export CSV pour analyse
- Export Excel avec graphiques

**Commande :**
```python
python scripts/generate_comparison_table.py \
  --output analysis_output \
  --format markdown,csv,excel
```

Le script génère automatiquement :
- `comparison_table.md` : Tableau markdown formaté
- `comparison_data.csv` : Données brutes exportables
- `comparison_analysis.xlsx` : Excel avec onglets multiples et graphiques

#### Format de présentation manuel (si script non utilisé)

```markdown
| Critère | VOUS | Concurrent 1 | Concurrent 2 | Concurrent 3 |
|---------|------|--------------|--------------|--------------|
| **PRICING & BUSINESS MODEL** |
| Prix entrée | XX€ | XX€ | XX€ | XX€ |
| Modèle | [Type] | [Type] | [Type] | [Type] |
| **POSITIONNEMENT** |
| Cible | [Segment] | [Segment] | [Segment] | [Segment] |
| Message clé | [UVP] | [UVP] | [UVP] | [UVP] |
| **CRITÈRES SECTORIELS** |
| [Critère 1] | ... | ... | ... | ... |
| **PERCEPTION** |
| Forces | ✅ A, B, C | ✅ X, Y | ✅ M, N | ✅ P, Q |
| Faiblesses | ❌ D, E | ❌ Z | ❌ O | ❌ R |
```

#### Scoring de positionnement

Pour chaque critère clé, noter sur 5 :
- ⭐⭐⭐⭐⭐ Excellent
- ⭐⭐⭐⭐ Très bon
- ⭐⭐⭐ Bon
- ⭐⭐ Moyen
- ⭐ Faible

---

### Analyse SWOT par concurrent

Pour chaque concurrent majeur, générer :

```markdown
## CONCURRENT : [Nom]

### Strengths (Forces) 💪
- Force 1 : [Description + pourquoi c'est fort]
- Force 2 : [Description + impact]
- Force 3 : [Description + avantage concurrentiel]

### Weaknesses (Faiblesses) ⚠️
- Faiblesse 1 : [Description + conséquence]
- Faiblesse 2 : [Point d'attaque potentiel]
- Faiblesse 3 : [Limitation identifiée]

### Opportunities (Opportunités pour VOUS) 🎯
- Opportunité 1 : [Ce que vous pouvez exploiter]
- Opportunité 2 : [Angle d'attaque suggéré]

### Threats (Menaces de leur part) 🚨
- Menace 1 : [Ce qu'ils pourraient faire]
- Menace 2 : [Évolution à surveiller]
```

---

## PHASE 3 : IDENTIFICATION DES OPPORTUNITÉS

### Méthodologie de détection des gaps

#### 1. ANGLES MORTS (Blind Spots)

**Définition :** Problèmes/besoins que PERSONNE n'adresse bien

**Questions à se poser :**
- Qu'est-ce qu'AUCUN concurrent ne fait ?
- Quels pain points sont ignorés par tous ?
- Quelles fonctionnalités sont systématiquement absentes ?

**Format de présentation :**
```markdown
### 🎯 ANGLE MORT #1 : [Titre du gap]

**Constat :**
- ❌ Concurrent A : [Pourquoi ils ne le font pas]
- ❌ Concurrent B : [Pourquoi ils ne le font pas]
- ❌ Concurrent C : [Pourquoi ils ne le font pas]

**Opportunité pour vous :**
💡 [Ce que vous pouvez proposer de unique]

**Impact estimé :**
📈 [Pourquoi c'est important - chiffres/tendances si disponibles]

**Barrières à l'entrée :**
- [Difficulté : Faible/Moyenne/Élevée]
- [Ressources nécessaires]

**Score d'opportunité : X/10**
```

---

#### 2. SEGMENTS SOUS-SERVIS

**Définition :** Cibles mal adressées par les solutions actuelles

**Format de présentation :**
```markdown
### 🎯 SEGMENT SOUS-SERVI : [Nom du segment]

**Profil du segment :**
- Taille : [Nombre estimé / TAM]
- Caractéristiques : [Spécificités]
- Pain points spécifiques : [Problèmes uniques]

**Pourquoi mal servi :**
- Raison 1 : [Ex: Trop cher pour eux]
- Raison 2 : [Ex: Trop complexe]
- Raison 3 : [Ex: Pas adapté à leur contexte]

**Comment vous pouvez les servir :**
💡 [Votre approche différente]

**Potentiel business :**
📈 [Estimation valeur / croissance]
```

---

#### 3. BESOINS NON-SATISFAITS

**Définition :** Fonctionnalités/services demandés mais inexistants

**Sources pour les identifier :**
- Avis clients négatifs récurrents
- Forums / Reddit / Communautés
- Feature requests dans les commentaires
- Plaintes communes sur tous les concurrents

**Format de présentation :**
```markdown
### 🎯 BESOIN NON-SATISFAIT : [Description du besoin]

**Demande :**
- Fréquence : [Combien de clients demandent ça]
- Urgence : [À quel point c'est critique]
- Sources : [Où vous avez vu cette demande]

**Pourquoi personne ne le fait :**
- Raison 1 : [Ex: Techniquement difficile]
- Raison 2 : [Ex: Pas rentable à court terme]
- Raison 3 : [Ex: Vision différente]

**Comment vous répondez :**
💡 [Votre solution au besoin]

**Différenciation créée :**
🏆 [En quoi ça vous démarque]
```

---

#### 4. TENDANCES ÉMERGENTES

**Définition :** Évolutions du marché que les concurrents n'ont pas encore intégrées

**Format de présentation :**
```markdown
### 🎯 TENDANCE ÉMERGENTE : [Nom de la tendance]

**La tendance :**
- Nature : [Techno / Réglementaire / Comportementale / Économique]
- Horizon : [Court/Moyen/Long terme]
- Maturité : [Émergente / En croissance / Mature]

**État du marché :**
- Concurrent A : ❌ Pas adapté / ⚠️ Partiellement / ✅ Bien positionné
- Concurrent B : [Même analyse]
- Concurrent C : [Même analyse]

**Votre avantage compétitif :**
💡 [Comment vous pouvez surfer sur cette tendance]

**First-mover advantage :**
⚡ [Bénéfice à être early adopter]
```

---

### Priorisation des opportunités

#### Appeler le script de visualisation des opportunités

Utiliser le script `scripts/generate_opportunity_matrix.py` pour créer :
- Matrice impact/facilité visuelle
- Graphique de scoring
- Tableau de priorisation

**Commande :**
```python
python scripts/generate_opportunity_matrix.py \
  --output analysis_output \
  --format png,svg
```

Le script génère :
- `opportunity_matrix.png` : Matrice visuelle 2x2
- `opportunity_scores.png` : Graphique à barres des scores
- `priority_ranking.md` : Tableau de priorisation

#### Matrice d'impact (si script non utilisé)

```
IMPACT sur le marché (Haut/Moyen/Bas)
       ↑
Élevé  │ 🥇 PRIORITÉ 1    🥈 PRIORITÉ 2
       │ (Quick wins)     (Investir)
       │
Moyen  │ 🥉 PRIORITÉ 3    🔄 CONSIDÉRER
       │ (Facile à faire) (Évaluer ROI)
       │
Bas    │ ❌ IGNORER       ❌ IGNORER
       │
       └────────────────────────────→
         Faible  →  Facilité d'exécution  →  Élevée
```

**Scoring d'opportunité (0-10) :**
- Impact marché : X/3
- Facilité exécution : X/3
- Différenciation créée : X/2
- Timing (momentum) : X/2
**TOTAL : X/10**

---

## PHASE 4 : STRATÉGIE & ACTIONNABILITÉ

### Positionnement différenciant

#### Proposition de Valeur Unique (UVP)

**Formule :**
```
[Votre solution] aide [cible précise] à [bénéfice principal]
en [différenciation clé], sans [objection/friction courante].
```

**Déclinaison par concurrent :**

```markdown
### Votre UVP générale :
"[Proposition de valeur]"

### VS Concurrent 1 :
"Contrairement à [Concurrent], nous [différence] ce qui permet [bénéfice]"

### VS Concurrent 2 :
"Là où [Concurrent] se concentre sur [leur focus], nous apportons [votre valeur ajoutée]"

### VS Concurrent 3 :
"[Concurrent] est excellent pour [leur force], mais si vous cherchez [besoin spécifique], nous sommes la meilleure option parce que [raison]"
```

---

### Battle Cards

#### Appeler le script de génération de battle cards visuelles

Utiliser le script `scripts/generate_battle_cards.py` pour créer :
- Battle cards PDF formatées
- Battle cards en images (PNG)
- Version imprimable

**Commande :**
```python
python scripts/generate_battle_cards.py \
  --output analysis_output \
  --format pdf,png
```

Le script génère :
- `battlecard_[concurrent].pdf` : Une battle card par concurrent
- `battlecard_[concurrent].png` : Version image
- `battlecards_all.pdf` : Toutes les battle cards ensemble

#### Format de battle card (si script non utilisé)

```markdown
## 🥊 BATTLE CARD : VS [CONCURRENT]

### À SAVOIR
- **Taille :** [Effectifs / CA / Parts de marché]
- **Fondation :** [Année / Fondateurs / Localisation]
- **Cible principale :** [Qui ils visent]
- **Prix moyen :** [Fourchette tarifaire]

### LEURS FORCES (à reconnaître)
✅ Force 1 : [Ce qu'ils font bien]
✅ Force 2 : [Leur avantage]
✅ Force 3 : [Pourquoi certains les choisissent]

### LEURS FAIBLESSES (à exploiter)
❌ Faiblesse 1 : [Limite identifiée]
❌ Faiblesse 2 : [Pain point client récurrent]
❌ Faiblesse 3 : [Ce qu'ils ne font pas]

### OBJECTIONS TYPIQUES & RÉPONSES

**Objection 1 : "Mais [Concurrent] a plus de fonctionnalités"**
→ Réponse : "C'est vrai que [Concurrent] a beaucoup de features. Maintenant,
[statistique] de leurs clients n'utilisent que [X%] des fonctionnalités.
Notre force, c'est qu'on se concentre sur [valeur essentielle], ce qui permet
[bénéfice concret]. Résultat : nos clients sont opérationnels en [délai] vs
[délai plus long] chez eux."

**Objection 2 : "[Concurrent] est le leader du marché"**
→ Réponse : "Absolument, ils sont leaders et c'est mérité. Maintenant, être
leader signifie aussi servir tout le monde, ce qui crée des compromis.
Pour [votre cible précise], nous sommes spécialisés et ça fait toute la
différence. Par exemple, [cas concret]."

**Objection 3 : "[Concurrent] est moins cher"**
→ Réponse : "Sur le prix d'entrée, oui. Maintenant, si on regarde le coût total
sur [période], [Concurrent] facture [frais cachés] + [limitations] qui font
que le coût réel est [X€]. Avec nous, c'est [prix transparent] tout compris,
ce qui revient à [comparaison]. Plus important encore, nos clients obtiennent
[ROI] en [délai], ce qui rentabilise l'investissement."

### QUAND LES RECOMMANDER (fair play)
"[Concurrent] est une excellente solution si vous [cas d'usage où ils excellent].
Dans ce cas, n'hésitez pas à les contacter."

### QUAND NOUS RECOMMANDER
"Nous sommes la meilleure option si vous :
- ✅ [Critère 1]
- ✅ [Critère 2]
- ✅ [Critère 3]"

### PREUVES SOCIALES À MENTIONNER
- Client qui est passé de [Concurrent] à nous : "[Témoignage court]"
- Cas d'usage : [Résultat chiffré obtenu]
- Comparatif : [Métrique où vous êtes meilleurs]
```

---

### Matrices de positionnement

#### Appeler le script de génération de matrices

Utiliser le script `scripts/generate_positioning_matrix.py` pour créer :
- Matrice Prix vs Valeur
- Matrice sur axes personnalisés
- Graphiques radar de positionnement

**Commande :**
```python
python scripts/generate_positioning_matrix.py \
  --output analysis_output \
  --format png,svg
```

Le script génère :
- `matrix_price_value.png` : Matrice Prix vs Valeur
- `matrix_custom_axes.png` : Matrice axes personnalisés
- `radar_positioning.png` : Graphique radar multi-critères

#### MATRICE 1 : Positionnement Prix vs Valeur

```
Valeur perçue
       ↑
Haute  │    [Concurrent Premium]
       │             [VOUS] ⭐
       │   [Concurrent Standard]
       │
Basse  │  [Concurrent Low-cost]
       │
       └────────────────────────────→
         Bas  ←  Prix  →  Élevé
```

**Analyse :**
- Vous : [Position + justification]
- Opportunité : [Espace libre identifié]

---

#### MATRICE 2 : Axes stratégiques personnalisés

**Exemples d'axes selon le secteur :**
- Simplicité vs Puissance
- Généraliste vs Spécialisé
- Self-service vs Accompagné
- Local vs Global
- Innovation vs Stabilité
- Volume vs Premium

```
[Axe vertical]
       ↑
Élevé  │   [Concurrent]  [VOUS] ⭐
       │          [Concurrent]
Moyen  │    [Concurrent]
       │
Bas    │   [Concurrent]
       │
       └────────────────────────────→
         Bas  ←  [Axe horizontal]  →  Élevé
```

---

#### MATRICE 3 : Océan Bleu (si skill disponible)

**Si ocean-bleu-skills détecté :**

```markdown
J'ai identifié [X] opportunités majeures qui correspondent parfaitement
à une stratégie Océan Bleu.

Voulez-vous que j'utilise le skill ocean-bleu-skills pour créer :
- Une matrice ERAC complète (Éliminer-Réduire-Augmenter-Créer)
- Un canevas stratégique visuel
- Une stratégie de différenciation radicale

à partir de ces gaps identifiés ?
```

**Si skill non disponible, générer une mini-matrice ERAC :**

```markdown
### APPROCHE OCÉAN BLEU : Créer un nouvel espace stratégique

**ÉLIMINER** (ce que les concurrents font mais qui n'apporte plus de valeur)
- ❌ Élément 1 : [Ex: Fonctionnalités complexes inutilisées]
- ❌ Élément 2 : [Ex: Processus lourds]

**RÉDUIRE** (ce qu'il faut diminuer par rapport aux standards)
- ⬇️ Élément 1 : [Ex: Prix d'entrée]
- ⬇️ Élément 2 : [Ex: Délai de mise en œuvre]

**AUGMENTER** (ce qu'il faut pousser au-delà du standard)
- ⬆️ Élément 1 : [Ex: Support client]
- ⬆️ Élément 2 : [Ex: Personnalisation]

**CRÉER** (ce qui n'existe pas encore dans l'industrie)
- ✨ Innovation 1 : [Nouvelle feature/service]
- ✨ Innovation 2 : [Nouvelle approche]
```

---

### Plan d'action

#### Quick Wins (0-3 mois)

**Actions immédiates à fort impact :**

```markdown
### 🚀 QUICK WIN #1 : [Action]
**Objectif :** [Résultat attendu]
**Pourquoi :** [Gap concurrent exploité]
**Comment :** [Étapes concrètes]
**Ressources :** [Ce dont vous avez besoin]
**Impact estimé :** [Métrique]
**Difficulté :** ⭐⭐ (Facile)

### 🚀 QUICK WIN #2 : [Action]
[Même structure]

### 🚀 QUICK WIN #3 : [Action]
[Même structure]
```

---

#### Stratégie moyen terme (3-12 mois)

```markdown
### 🎯 AXE STRATÉGIQUE 1 : [Thème]
**Objectif :** Devenir reconnu comme [positionnement voulu]

**Actions :**
1. [Action 1] - Q[X]
2. [Action 2] - Q[X]
3. [Action 3] - Q[X]

**Résultat attendu :** [Impact business]

### 🎯 AXE STRATÉGIQUE 2 : [Thème]
[Même structure]
```

---

#### Veille concurrentielle continue

```markdown
### 🔍 ALERTES CONCURRENTIELLES

**Concurrent A :**
- ⚠️ Surveiller : [Évolution à suivre]
- 🚨 Risque : [Menace potentielle]
- 📅 Check : [Quand re-analyser]

**Concurrent B :**
[Même structure]

**Tendances marché :**
- 📈 Tendance 1 : [À capitaliser]
- 📊 Tendance 2 : [À surveiller]
```

---

## FORMATS DE SORTIE

### Format 1 : Document Markdown (principal)

**Structure du document généré :**

```
# ANALYSE CONCURRENTIELLE : [Votre entreprise]
Date : [Date]
Secteur : [Secteur]

## EXECUTIVE SUMMARY
- [Synthèse en 5 points clés]

## 1. VOTRE POSITIONNEMENT ACTUEL
## 2. VOS CONCURRENTS ANALYSÉS
## 3. TABLEAU COMPARATIF DÉTAILLÉ
## 4. ANALYSE SWOT PAR CONCURRENT
## 5. OPPORTUNITÉS DE MARCHÉ (Gaps identifiés)
## 6. MATRICES DE POSITIONNEMENT
## 7. STRATÉGIE DE DIFFÉRENCIATION
## 8. BATTLE CARDS
## 9. PLAN D'ACTION
## 10. ANNEXES (Sources, Méthodologie)
```

---

### Format 2 : Tableaux comparatifs (Excel/CSV)

Utiliser `scripts/generate_comparison_table.py` pour créer :

**Fichier généré avec 3 onglets :**

**Onglet 1 : Comparaison générale**
- Tableau principal avec tous les critères

**Onglet 2 : Scoring**
- Notes par critère
- Graphiques radars de positionnement

**Onglet 3 : Opportunités**
- Liste des gaps avec scoring
- Matrice de priorisation

---

### Format 3 : Présentation visuelle (PowerPoint structure)

**Slides suggérées :**

```
Slide 1 : Titre + Contexte
Slide 2 : Executive Summary (5 insights clés)
Slide 3 : Panorama concurrentiel (logos + positionnement)
Slide 4-8 : 1 slide par concurrent (SWOT visuel)
Slide 9 : Tableau comparatif (top critères)
Slide 10 : Matrice de positionnement Prix vs Valeur
Slide 11 : Matrice axes stratégiques
Slide 12-14 : Top 3 opportunités (1 slide chacune)
Slide 15 : Votre positionnement différenciant (UVP)
Slide 16 : Quick Wins (plan 90 jours)
Slide 17 : Recommandations stratégiques
```

Utiliser les scripts pour générer les visuels :
- `generate_positioning_matrix.py` pour les matrices
- `generate_opportunity_matrix.py` pour les opportunités
- `generate_battle_cards.py` pour les battle cards

---

## SCRIPTS DISPONIBLES

### 1. generate_comparison_table.py
Créer des tableaux comparatifs multi-formats (Markdown, CSV, Excel).

### 2. generate_positioning_matrix.py
Générer des matrices de positionnement visuelles (Prix/Valeur, axes personnalisés, radar).

### 3. generate_opportunity_matrix.py
Visualiser les opportunités identifiées (matrice 2x2, scoring, priorisation).

### 4. generate_battle_cards.py
Créer des battle cards visuelles professionnelles (PDF, PNG).

Voir `references/scripts_documentation.md` pour la documentation complète des scripts.

---

## RESSOURCES COMPLÉMENTAIRES

Voir le dossier `references/` pour :
- `methodology_guide.md` : Guide méthodologique détaillé
- `sector_criteria.md` : Critères d'analyse par secteur
- `sources_template.md` : Template de sources et méthodologie
- `scripts_documentation.md` : Documentation des scripts Python

---

## ERREURS À ÉVITER

### Top 10 des erreurs d'analyse concurrentielle

❌ **1. Analyser trop de concurrents**
→ Rester sur 3-5 max, aller en profondeur

❌ **2. Ignorer les concurrents indirects**
→ Identifier aussi les substituts

❌ **3. Sous-estimer les concurrents**
→ Reconnaître leurs forces objectivement

❌ **4. Sur-estimer sa propre solution**
→ Être honnête sur ses faiblesses

❌ **5. Analyse statique (one-shot)**
→ Mettre en place veille continue

❌ **6. Focus uniquement sur les features**
→ Analyser aussi positionnement, prix, support, expérience

❌ **7. Ignorer les avis clients**
→ C'est là qu'on trouve les vrais pain points

❌ **8. Ne pas prioriser les opportunités**
→ Tout faire = rien faire bien

❌ **9. Analyse sans action**
→ Toujours finir avec plan concret

❌ **10. Ne pas partager avec l'équipe**
→ Battle cards inutiles si dans un tiroir

---

**FIN DU SKILL COMPETITIVE-ANALYSIS-EXPRESS**

Ce skill permet de réaliser rapidement une analyse concurrentielle stratégique qui identifie les vrais gaps de marché et génère des arguments différenciants actionnables pour l'équipe commerciale et marketing.
